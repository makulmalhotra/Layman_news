# Layman — AI Context File for Claude Code

## Project Overview
"Layman" is a SwiftUI news app covering business, tech & startups in plain everyday language.
Target: iOS 26.2 | Xcode 26.3 | Swift 6.2 (SWIFT_DEFAULT_ACTOR_ISOLATION = MainActor)

## Architecture
- **Pattern**: MVVM — ViewModels are `@Observable` classes
- **Navigation**: Manual state enum in `mm_newsApp.swift` (`AppScreen`)
- **Styling**: All colors/fonts defined in `Theme.swift` as `Color` / `Font` extensions
- **File layout**: All `.swift` files at `mm_news/` root — `PBXFileSystemSynchronizedRootGroup` picks them up automatically (no pbxproj edits needed)

## Swift 6.2 Gotchas (IMPORTANT)
- `SWIFT_DEFAULT_ACTOR_ISOLATION = MainActor` is enabled → all code is implicitly `@MainActor`
- **Font ambiguity**: `Text.font(_:)` and `View.font(_:)` are both `nonisolated` in iOS 26 SwiftUI, causing "ambiguous use of 'font'" errors. Fix: apply `.frame(maxWidth:)` or another layout modifier BEFORE `.font(...)` so the type becomes `some View` (only `View.font` then applies).
- Arithmetic with `CGFloat` in opacity/opacity expressions: use explicit `Double(...)` casts.
- `Gradient.Stop(color:location:)` — must be fully explicit (not `.init(color:location:)`).

## Color Palette
| Token | Hex | Usage |
|---|---|---|
| `laymanOrange` | #DE6629 | Accent, CTA buttons, "made simple" |
| `laymanDarkOrange` | #CC5214 | Gradient thumb, hover states |
| `laymanText` | #231C12 | Primary text |
| `laymanSubtext` | #665744 | Secondary/caption text |
| `laymanBackground` | #F7EFE6 | App background, cards |
| `gradientTop` | #FAE8D1 | Welcome screen gradient top |
| `gradientMid` | #F0C499 | Welcome screen gradient mid |
| `gradientBottom` | #E69E66 | Welcome screen gradient bottom |

## Screens (4 total)
1. **WelcomeView** — gradient bg, logo, slogan, swipe-to-start slider ✅
2. **AuthView** — Supabase email/password login + signup (TBD)
3. **HomeView** — Carousel + Today's Picks + tab bar (TBD)
4. **ArticleDetailView** — 3 swipeable content cards (TBD)

## External Services
- **Supabase**: Auth + `saved_articles` table. Credentials in `Config.swift` (excluded from git via `.gitignore`)
- **NewsData.io**: Free-tier news API. API key in `Config.swift`

## Headline Rules
- Max 48–52 characters (7–9 words)
- Casual, conversational tone — not formal news-speak
- Example: "This AI startup just raised $40M to build faster chips"

## Content Card Rules
- 3 swipeable cards per article
- 28–35 words per card, filling exactly 6 lines
- Written in layman's terms — simple, everyday language
