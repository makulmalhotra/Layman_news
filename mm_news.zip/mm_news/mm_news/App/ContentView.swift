// ContentView.swift — entry point is managed by mm_newsApp.swift
import SwiftUI
