import SwiftUI

enum AppScreen: Equatable {
    case welcome
    case auth
    case home
}

@main
struct mm_newsApp: App {
    @State private var currentScreen: AppScreen = .welcome
    @State private var authViewModel = AuthViewModel()
    @Environment(\.scenePhase) private var scenePhase

    var body: some Scene {
        WindowGroup {
            ZStack {
                switch currentScreen {
                case .welcome:
                    WelcomeView(onGetStarted: { currentScreen = .auth })

                case .auth:
                    AuthView(viewModel: authViewModel)
                        .onChange(of: authViewModel.isAuthenticated) { _, isAuth in
                            if isAuth {
                                withAnimation(.easeInOut(duration: 0.38)) { currentScreen = .home }
                            }
                        }

                case .home:
                    MainTabView(authViewModel: authViewModel)
                        .onChange(of: authViewModel.isAuthenticated) { _, isAuth in
                            if !isAuth {
                                withAnimation(.easeInOut(duration: 0.38)) { currentScreen = .welcome }
                            }
                        }
                }
            }
            .animation(.easeInOut(duration: 0.38), value: currentScreen)
            .onAppear {
                authViewModel.restoreSession()
                if authViewModel.isAuthenticated { currentScreen = .home }
                // Request notification permission once
                Task { await NotificationService.shared.requestPermission() }
            }
        }
        // Realtime sync trigger: notify when app comes to foreground
        .onChange(of: scenePhase) { _, phase in
            if phase == .active {
                NotificationCenter.default.post(name: .appBecameActive, object: nil)
            }
        }
    }
}

extension Notification.Name {
    static let appBecameActive = Notification.Name("laymanAppBecameActive")
}
