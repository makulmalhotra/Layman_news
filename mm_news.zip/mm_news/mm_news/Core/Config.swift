import Foundation

/// ⚠️  Replace placeholder values with your real keys before running.
/// Keep this file in .gitignore — never commit real credentials.
enum AppConfig {

    // MARK: - Supabase
    static let supabaseURL      = "https://rfkgtxdroiwkldgbtcjr.supabase.co"
    static let supabaseAnonKey  = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJma2d0eGRyb2l3a2xkZ2J0Y2pyIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzUyMDI0NTEsImV4cCI6MjA5MDc3ODQ1MX0.C1QeNlW5D0RangErA7MHvg0Vwycch-Ubtp6_uNRyUIY"

    // MARK: - Gemini AI (free tier) — https://aistudio.google.com
    static let geminiAPIKey = "AIzaSyDDoobv1GUDV1k0OS4pWY8oUrZZf0e_uU8"
    static let geminiModel  = "gemini-flash-lite-latest"

    // MARK: - NewsData.io
    static let newsAPIKey       = "pub_3bbeaad3e7594d19bc696fc7e9e86641"
    static let newsCategories   = "technology,business"
    static let newsLanguage     = "en"
    static let newsPageSize     = 10
}
