import Foundation
import Security

/// Thin Keychain wrapper for securely storing the user session.
struct KeychainHelper {
    private static let service = "com.layman.newsapp"
    private static let sessionKey = "user_session"

    static func saveSession(_ session: StoredSession) {
        guard let data = try? JSONEncoder().encode(session) else { return }
        save(key: sessionKey, data: data)
    }

    static func loadSession() -> StoredSession? {
        guard let data = load(key: sessionKey) else { return nil }
        return try? JSONDecoder().decode(StoredSession.self, from: data)
    }

    static func deleteSession() {
        delete(key: sessionKey)
    }

    // MARK: - Private CRUD
    private static func save(key: String, data: Data) {
        let query: [String: Any] = [
            kSecClass as String:       kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: key,
            kSecValueData as String:   data
        ]
        SecItemDelete(query as CFDictionary)
        SecItemAdd(query as CFDictionary, nil)
    }

    private static func load(key: String) -> Data? {
        let query: [String: Any] = [
            kSecClass as String:            kSecClassGenericPassword,
            kSecAttrService as String:      service,
            kSecAttrAccount as String:      key,
            kSecReturnData as String:       true,
            kSecMatchLimit as String:       kSecMatchLimitOne
        ]
        var result: AnyObject?
        let status = SecItemCopyMatching(query as CFDictionary, &result)
        guard status == errSecSuccess else { return nil }
        return result as? Data
    }

    private static func delete(key: String) {
        let query: [String: Any] = [
            kSecClass as String:       kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: key
        ]
        SecItemDelete(query as CFDictionary)
    }
}
