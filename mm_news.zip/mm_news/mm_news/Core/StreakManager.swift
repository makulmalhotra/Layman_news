import Foundation

// MARK: - Reading Streak Tracker
final class StreakManager {
    static let shared = StreakManager()
    private init() {}

    private let streakKey   = "layman_streak_count"
    private let lastReadKey = "layman_last_read_date"
    private let longestKey  = "layman_longest_streak"

    var currentStreak: Int  { UserDefaults.standard.integer(forKey: streakKey) }
    var longestStreak: Int  { UserDefaults.standard.integer(forKey: longestKey) }

    var todayRead: Bool {
        guard let last = UserDefaults.standard.object(forKey: lastReadKey) as? Date else { return false }
        return Calendar.current.isDateInToday(last)
    }

    /// Call when the user opens any article. Updates streak once per calendar day.
    func recordRead() {
        let cal   = Calendar.current
        let today = cal.startOfDay(for: Date())

        if let lastRead = UserDefaults.standard.object(forKey: lastReadKey) as? Date {
            let lastDay = cal.startOfDay(for: lastRead)
            let days    = cal.dateComponents([.day], from: lastDay, to: today).day ?? 0
            switch days {
            case 0:  return    // already counted today
            case 1:            // consecutive day
                let newStreak = currentStreak + 1
                UserDefaults.standard.set(newStreak, forKey: streakKey)
                if newStreak > longestStreak {
                    UserDefaults.standard.set(newStreak, forKey: longestKey)
                }
            default:           // streak broken
                UserDefaults.standard.set(1, forKey: streakKey)
            }
        } else {
            // First ever read
            UserDefaults.standard.set(1, forKey: streakKey)
            UserDefaults.standard.set(1, forKey: longestKey)
        }
        UserDefaults.standard.set(today, forKey: lastReadKey)
    }
}
