import SwiftUI

// MARK: - Dynamic color palette (Light + Dark mode)
extension Color {

    // Primary accent — vivid in both modes
    static let laymanOrange     = Color(UIColor { t in
        t.userInterfaceStyle == .dark
            ? UIColor(red: 0.92, green: 0.47, blue: 0.22, alpha: 1)  // #EB7838 — pops on dark
            : UIColor(red: 0.87, green: 0.40, blue: 0.16, alpha: 1)  // #DE6629
    })
    static let laymanDarkOrange = Color(UIColor { t in
        t.userInterfaceStyle == .dark
            ? UIColor(red: 0.78, green: 0.34, blue: 0.10, alpha: 1)  // #C7561A
            : UIColor(red: 0.80, green: 0.32, blue: 0.08, alpha: 1)  // #CC5214
    })

    // Adaptive text — warm cream in dark
    static let laymanText = Color(UIColor { t in
        t.userInterfaceStyle == .dark
            ? UIColor(red: 0.96, green: 0.92, blue: 0.87, alpha: 1)  // #F5EBE0 warm cream
            : UIColor(red: 0.14, green: 0.11, blue: 0.07, alpha: 1)  // #231C12
    })
    static let laymanSubtext = Color(UIColor { t in
        t.userInterfaceStyle == .dark
            ? UIColor(red: 0.65, green: 0.53, blue: 0.44, alpha: 1)  // #A68770 warm caramel
            : UIColor(red: 0.40, green: 0.34, blue: 0.26, alpha: 1)  // #665744
    })

    // Adaptive backgrounds — dark espresso theme
    static let laymanBackground = Color(UIColor { t in
        t.userInterfaceStyle == .dark
            ? UIColor(red: 0.10, green: 0.08, blue: 0.06, alpha: 1)  // #1A140F deep espresso
            : UIColor(red: 0.97, green: 0.94, blue: 0.90, alpha: 1)  // #F7EFE6 cream
    })

    /// Elevated card surface — clearly distinct from background
    static let laymanCard = Color(UIColor { t in
        t.userInterfaceStyle == .dark
            ? UIColor(red: 0.17, green: 0.13, blue: 0.10, alpha: 1)  // #2B211A warm caramel dark
            : UIColor(red: 0.93, green: 0.87, blue: 0.80, alpha: 1)  // #EDE0CC warm tan
    })

    /// Tab bar & top nav bar surface
    static let laymanTabBar = Color(UIColor { t in
        t.userInterfaceStyle == .dark
            ? UIColor(red: 0.13, green: 0.10, blue: 0.08, alpha: 1)  // #221A14 slightly lifted
            : UIColor.white
    })

    /// Input field / sheet surface — subtle lift above card
    static let laymanSurface = Color(UIColor { t in
        t.userInterfaceStyle == .dark
            ? UIColor(red: 0.21, green: 0.16, blue: 0.12, alpha: 1)  // #362920 warm mid surface
            : UIColor.white
    })

    // Welcome gradient stops — adaptive light/dark
    static let gradientTop = Color(UIColor { t in
        t.userInterfaceStyle == .dark
            ? UIColor(red: 0.12, green: 0.09, blue: 0.07, alpha: 1)  // #1E1712 deep espresso
            : UIColor(red: 0.98, green: 0.91, blue: 0.82, alpha: 1)  // #FAE8D1 cream
    })
    static let gradientMid = Color(UIColor { t in
        t.userInterfaceStyle == .dark
            ? UIColor(red: 0.20, green: 0.13, blue: 0.09, alpha: 1)  // #332116 warm dark brown
            : UIColor(red: 0.94, green: 0.77, blue: 0.60, alpha: 1)  // #F0C499
    })
    static let gradientBottom = Color(UIColor { t in
        t.userInterfaceStyle == .dark
            ? UIColor(red: 0.35, green: 0.20, blue: 0.10, alpha: 1)  // #59331A rich caramel
            : UIColor(red: 0.90, green: 0.62, blue: 0.40, alpha: 1)  // #E69E66
    })
}

extension Font {
    static func laymanTitle(_ size: CGFloat, weight: Font.Weight = .semibold) -> Font {
        .system(size: size, weight: weight, design: .serif)
    }
    static func laymanBody(_ size: CGFloat, weight: Font.Weight = .regular) -> Font {
        .system(size: size, weight: weight, design: .default)
    }
}

// MARK: - Press-scale button style
struct ScaleButtonStyle: ButtonStyle {
    var scale: CGFloat = 0.94
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .scaleEffect(configuration.isPressed ? scale : 1.0)
            .animation(.spring(response: 0.25, dampingFraction: 0.65), value: configuration.isPressed)
    }
}
