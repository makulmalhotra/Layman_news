import Foundation

// MARK: - Chat message model
struct ChatMessage: Identifiable, Equatable {
    let id: UUID
    let role: MessageRole
    let content: String
    let timestamp: Date

    init(role: MessageRole, content: String) {
        self.id        = UUID()
        self.role      = role
        self.content   = content
        self.timestamp = Date()
    }
}

enum MessageRole: Equatable {
    case bot
    case user
}

// MARK: - Groq API request/response models
struct GroqRequest: Encodable {
    let model: String
    let messages: [GroqMessage]
    let maxTokens: Int
    let temperature: Double

    enum CodingKeys: String, CodingKey {
        case model, messages, temperature
        case maxTokens = "max_tokens"
    }
}

struct GroqMessage: Codable {
    let role: String    // "system" | "user" | "assistant"
    let content: String
}

struct GroqResponse: Decodable {
    struct Choice: Decodable {
        struct Message: Decodable { let content: String }
        let message: Message
    }
    let choices: [Choice]

    var text: String { choices.first?.message.content ?? "" }
}
