import Foundation

// MARK: - News Article (NewsData.io)
struct Article: Identifiable, Codable, Equatable, Hashable {
    var id: String { articleId ?? link ?? title }

    let articleId: String?
    let title: String
    let link: String?
    let description: String?
    let content: String?        // free tier returns "ONLY AVAILABLE IN PAID PLANS" — ignored below
    let imageUrl: String?
    let sourceId: String?
    let pubDate: String?
    let category: [String]?
    let creator: [String]?

    enum CodingKeys: String, CodingKey {
        case articleId  = "article_id"
        case title, link, description, content
        case imageUrl   = "image_url"
        case sourceId   = "source_id"
        case pubDate    = "pub_date"
        case category, creator
    }

    // MARK: - Helpers

    /// Best available body text — ignores the paid-plan placeholder.
    var bodyText: String {
        let paid = "ONLY AVAILABLE IN"
        if let c = content, !c.hasPrefix(paid), !c.isEmpty { return c }
        return description ?? ""
    }

    /// Conversational headline, max 52 chars / 8 words.
    var laymanTitle: String {
        let t = title.trimmingCharacters(in: .whitespaces)
        guard t.count > 52 else { return t }
        let words = t.split(separator: " ")
        var result = ""
        for word in words {
            let candidate = result.isEmpty ? String(word) : result + " " + word
            if candidate.count <= 49 { result = candidate } else { break }
        }
        return result + "…"
    }

    var sourceName: String {
        sourceId?.replacingOccurrences(of: "_", with: " ").capitalized ?? "News"
    }

    /// NewsData.io free-tier pubDate: "2024-01-15 08:30:00"
    var formattedDate: String {
        guard let raw = pubDate else { return "" }
        // Try "yyyy-MM-dd HH:mm:ss"
        let spaceFormatter = DateFormatter()
        spaceFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
        spaceFormatter.locale = Locale(identifier: "en_US_POSIX")
        if let date = spaceFormatter.date(from: raw) {
            let out = DateFormatter()
            out.dateStyle = .medium
            out.timeStyle = .none
            return out.string(from: date)
        }
        // Fallback: show first 10 chars
        return String(raw.prefix(10))
    }

    // MARK: - 3 swipeable content cards (28-35 words each, ~6 lines)
    var contentCards: [String] {
        let body = bodyText.trimmingCharacters(in: .whitespaces)

        // Split into sentences
        let rawSentences = body
            .components(separatedBy: ". ")
            .map { $0.trimmingCharacters(in: .whitespaces) }
            .filter { $0.split(separator: " ").count >= 3 }   // drop fragments

        // We need 3 chunks of ~30 words each
        let chunks = buildThreeChunks(from: rawSentences, headline: title)
        return chunks
    }

    private func buildThreeChunks(from sentences: [String], headline: String) -> [String] {
        // Total words available
        let allWords = sentences.joined(separator: " ").split(separator: " ").map(String.init)

        // Target: 30 words per card
        let target = 30
        var cards: [String] = []

        if allWords.count >= target * 2 {
            // Enough real content — split into thirds
            let third = allWords.count / 3
            for i in 0..<3 {
                let start = i * third
                let end   = min(start + target, allWords.count)
                let chunk = allWords[start..<end].joined(separator: " ")
                cards.append(polish(chunk))
            }
        } else if !allWords.isEmpty {
            // Short description — spread across 3 cards with context framing
            let desc = allWords.joined(separator: " ")
            let half = allWords.count / 2

            let card1 = allWords.prefix(max(half, min(allWords.count, target))).joined(separator: " ")
            let card2 = allWords.suffix(max(1, allWords.count - half)).joined(separator: " ")
            let card3words = allWords.prefix(target).joined(separator: " ")
            let card3 = "Here's the short version: \(card3words)"

            cards = [polish(card1), polish(card2), polish(card3)]
        } else {
            // No text at all — use headline as filler
            let filler = "This story is about: \(headline). Tap the link icon above to read the full article from the original source and get all the details."
            cards = Array(repeating: filler, count: 3)
        }

        // Pad to exactly 3
        while cards.count < 3 { cards.append(cards.last ?? "") }
        return Array(cards.prefix(3))
    }

    private func polish(_ text: String) -> String {
        var t = text.trimmingCharacters(in: .whitespaces)
        if !t.hasSuffix(".") && !t.hasSuffix("!") && !t.hasSuffix("?") { t += "." }
        // Capitalise first letter
        guard let first = t.first else { return t }
        return first.uppercased() + t.dropFirst()
    }
}

// MARK: - NewsData.io API response
struct NewsResponse: Codable {
    let status: String
    let totalResults: Int?
    let results: [Article]?
    let nextPage: String?
}

// MARK: - Auth Models (Supabase)
struct AuthRequest: Codable {
    let email: String
    let password: String
}

struct AuthResponse: Codable {
    let accessToken: String?
    let tokenType: String?
    let expiresIn: Int?
    let refreshToken: String?
    let user: SupabaseUser?

    enum CodingKeys: String, CodingKey {
        case accessToken  = "access_token"
        case tokenType    = "token_type"
        case expiresIn    = "expires_in"
        case refreshToken = "refresh_token"
        case user
    }
}

struct SupabaseUser: Codable {
    let id: String
    let email: String?
}

struct StoredSession: Codable {
    let accessToken: String
    let refreshToken: String
    let userId: String
    let email: String
}

// MARK: - Saved Article (Supabase table)
struct SavedArticleDB: Identifiable, Codable {
    let id: Int?
    let userId: String?
    let articleId: String
    let title: String
    let link: String?
    let imageUrl: String?
    let sourceId: String?
    let pubDate: String?
    let createdAt: String?

    enum CodingKeys: String, CodingKey {
        case id
        case userId    = "user_id"
        case articleId = "article_id"
        case title, link
        case imageUrl  = "image_url"
        case sourceId  = "source_id"
        case pubDate   = "pub_date"
        case createdAt = "created_at"
    }

    func toArticle() -> Article {
        Article(
            articleId: articleId,
            title: title,
            link: link,
            description: nil,
            content: nil,
            imageUrl: imageUrl,
            sourceId: sourceId,
            pubDate: pubDate,
            category: nil,
            creator: nil
        )
    }
}
