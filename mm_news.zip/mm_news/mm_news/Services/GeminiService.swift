import Foundation

/// Calls the Google Gemini free-tier API.
/// Get a free key at https://aistudio.google.com → Get API key
actor GeminiService {

    private let session = URLSession.shared

    var isDemoMode: Bool { AppConfig.geminiAPIKey.contains("YOUR_GEMINI") }

    private var endpoint: String {
        "https://generativelanguage.googleapis.com/v1beta/models/\(AppConfig.geminiModel):generateContent"
    }

    // MARK: - Generate 3 question suggestions for an article
    func generateSuggestions(for article: Article) async throws -> [String] {
        if isDemoMode { return demoSuggestions(for: article) }

        let system = """
        Given a news article, generate exactly 3 short questions a curious reader might ask. \
        Each question must be 5–9 words. \
        Return only the 3 questions, one per line, no numbering, no extra text.
        """

        let user = "Article title: \(article.title)\nSummary: \(article.bodyText.prefix(300))"
        let raw = try await call(system: system, userText: user, maxTokens: 80)

        let lines = raw
            .components(separatedBy: "\n")
            .map { $0.trimmingCharacters(in: .whitespaces)
                     .trimmingCharacters(in: CharacterSet(charactersIn: "0123456789.-) ")) }
            .filter { $0.count > 8 }
            .prefix(3)
            .map { String($0) }

        if lines.count == 3 { return lines }
        return demoSuggestions(for: article)
    }

    // MARK: - Send a chat message and return AI response
    func chat(
        question: String,
        article: Article,
        history: [ChatMessage]
    ) async throws -> String {
        if isDemoMode { return demoResponse() }

        let system = """
        You are Layman — a friendly, no-nonsense news assistant. \
        Your job is to explain business and tech news in plain, everyday English.

        Article the user is reading:
        Title: \(article.title)
        Summary: \(article.bodyText.prefix(500))

        Rules you MUST follow:
        - Answer in exactly 1–2 sentences. Never more.
        - Use simple, casual language. No jargon, no buzzwords.
        - Be direct — give the answer first, explanation second.
        - Stay focused on this article's topic.
        """

        // Build conversation history (last 6 exchanges, skip initial bot greeting)
        var contents: [GeminiContent] = []
        for msg in history.dropFirst().suffix(6) {
            let role = msg.role == .user ? "user" : "model"
            contents.append(GeminiContent(role: role, parts: [GeminiPart(text: msg.content)]))
        }
        contents.append(GeminiContent(role: "user", parts: [GeminiPart(text: question)]))

        let raw = try await callWithContents(contents, system: system, maxTokens: 120)
        return raw.trimmingCharacters(in: .whitespacesAndNewlines)
    }

    // MARK: - Private helpers
    private func call(system: String, userText: String, maxTokens: Int) async throws -> String {
        let contents = [GeminiContent(role: "user", parts: [GeminiPart(text: userText)])]
        return try await callWithContents(contents, system: system, maxTokens: maxTokens)
    }

    private func callWithContents(
        _ contents: [GeminiContent],
        system: String,
        maxTokens: Int
    ) async throws -> String {
        var req = URLRequest(url: URL(string: endpoint)!)
        req.httpMethod = "POST"
        req.setValue("application/json",        forHTTPHeaderField: "Content-Type")
        req.setValue(AppConfig.geminiAPIKey,    forHTTPHeaderField: "X-goog-api-key")

        let body = GeminiRequest(
            contents: contents,
            systemInstruction: GeminiSystemInstruction(
                parts: [GeminiPart(text: system)]
            ),
            generationConfig: GeminiGenerationConfig(
                maxOutputTokens: maxTokens,
                temperature: 0.7
            )
        )
        req.httpBody = try JSONEncoder().encode(body)

        let (data, response) = try await session.data(for: req)
        if let http = response as? HTTPURLResponse, http.statusCode != 200 {
            let msg = String(data: data, encoding: .utf8) ?? "Unknown error"
            throw GeminiError.httpError(http.statusCode, msg)
        }
        let decoded = try JSONDecoder().decode(GeminiResponse.self, from: data)
        return decoded.text
    }

    // MARK: - Demo / fallback
    private func demoSuggestions(for article: Article) -> [String] {
        let title = article.title.lowercased()
        if title.contains("apple") || title.contains("iphone") {
            return ["How does this affect iPhone users?",
                    "Why is Apple doing this now?",
                    "Will this cost consumers more money?"]
        } else if title.contains("ai") || title.contains("openai") || title.contains("gemini") {
            return ["How does this AI actually work?",
                    "Should I be worried about my job?",
                    "Who benefits the most from this?"]
        } else if title.contains("tesla") || title.contains("elon") {
            return ["Why did Elon Musk do this?",
                    "How does this affect Tesla stock?",
                    "Will this change the EV market?"]
        } else if title.contains("google") || title.contains("amazon") || title.contains("meta") {
            return ["How big is this company really?",
                    "How does this affect regular users?",
                    "What does this mean for competitors?"]
        }
        return ["What is the main takeaway here?",
                "How does this affect everyday people?",
                "Why is this news important right now?"]
    }

    private func demoResponse() -> String {
        "To get real AI answers, add your free Gemini API key in Config.swift — get one at aistudio.google.com in under a minute. It's totally free!"
    }
}

// MARK: - Gemini API models
private struct GeminiRequest: Encodable {
    let contents: [GeminiContent]
    let systemInstruction: GeminiSystemInstruction
    let generationConfig: GeminiGenerationConfig
    // No CodingKeys — encoder uses camelCase as-is, which matches Gemini REST API
}

struct GeminiContent: Codable {
    let role: String
    let parts: [GeminiPart]
}

struct GeminiPart: Codable {
    let text: String
}

private struct GeminiSystemInstruction: Encodable {
    let parts: [GeminiPart]
}

private struct GeminiGenerationConfig: Encodable {
    let maxOutputTokens: Int
    let temperature: Double
    // No CodingKeys — camelCase matches Gemini API directly
}

private struct GeminiResponse: Decodable {
    struct Candidate: Decodable {
        struct Content: Decodable {
            let parts: [GeminiPart]
        }
        let content: Content
    }
    let candidates: [Candidate]

    var text: String { candidates.first?.content.parts.first?.text ?? "" }
}

enum GeminiError: LocalizedError {
    case httpError(Int, String)
    var errorDescription: String? {
        switch self {
        case .httpError(let c, _) where c == 400: return "Bad request — check your Gemini API key."
        case .httpError(let c, _) where c == 403: return "Invalid Gemini API key. Check Config.swift."
        case .httpError(let c, let m):             return "Gemini error \(c): \(m)"
        }
    }
}
