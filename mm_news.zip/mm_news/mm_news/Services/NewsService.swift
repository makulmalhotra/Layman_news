import Foundation

/// Fetches real business/tech/startup articles from NewsData.io (free tier).
actor NewsService {

    private let session = URLSession.shared

    // MARK: - Public fetch
    func fetchArticles(page: String? = nil) async throws -> [Article] {
        // Use mock data when the API key hasn't been configured yet
        guard !AppConfig.newsAPIKey.contains("YOUR_NEWSDATA") else {
            return mockArticles
        }

        var components = URLComponents(string: "https://newsdata.io/api/1/news")!
        var items: [URLQueryItem] = [
            .init(name: "apikey",   value: AppConfig.newsAPIKey),
            .init(name: "category", value: AppConfig.newsCategories),
            .init(name: "language", value: AppConfig.newsLanguage),
            .init(name: "size",     value: "\(AppConfig.newsPageSize)")
        ]
        if let page { items.append(.init(name: "page", value: page)) }
        components.queryItems = items

        guard let url = components.url else { throw NewsError.invalidURL }

        let (data, response) = try await session.data(from: url)

        if let http = response as? HTTPURLResponse, http.statusCode != 200 {
            // Parse NewsData error body if possible
            if let body = try? JSONDecoder().decode(NewsErrorBody.self, from: data) {
                throw NewsError.apiError(body.results.message)
            }
            throw NewsError.httpError(http.statusCode)
        }

        let decoded = try JSONDecoder().decode(NewsResponse.self, from: data)
        // Filter out articles with no usable content
        let articles = (decoded.results ?? []).filter { !$0.title.isEmpty }
        return articles
    }
}

// MARK: - Error types
enum NewsError: LocalizedError {
    case invalidURL
    case httpError(Int)
    case apiError(String)

    var errorDescription: String? {
        switch self {
        case .invalidURL:          return "Invalid URL."
        case .httpError(let c):    return "HTTP \(c) — check your NewsData.io API key in Config.swift."
        case .apiError(let msg):   return msg
        }
    }
}

private struct NewsErrorBody: Decodable {
    struct Results: Decodable { let message: String }
    let results: Results
}

// MARK: - Mock articles (shown when API key is placeholder)
private let mockArticles: [Article] = [
    Article(
        articleId: "mock-1",
        title: "OpenAI's new model beats every benchmark — here's what that means",
        link: "https://openai.com",
        description: "OpenAI just dropped GPT-5 and it's outperforming every other AI model on the planet right now. Researchers say it can write code, pass medical exams, and hold conversations that feel almost human. The company believes this is the biggest leap since ChatGPT launched.",
        content: nil,
        imageUrl: nil,
        sourceId: "techcrunch",
        pubDate: "2025-04-03 09:00:00",
        category: ["technology"],
        creator: ["Staff Writer"]
    ),
    Article(
        articleId: "mock-2",
        title: "Apple is building its own AI chip — and it's faster than Nvidia's",
        link: "https://apple.com",
        description: "Apple is reportedly designing a new AI chip in-house that's set to be twice as fast as Nvidia's current best. The chip would power everything from Siri to on-device image generation. Analysts say this could save Apple billions and give them a big edge over rivals.",
        content: nil,
        imageUrl: nil,
        sourceId: "bloomberg",
        pubDate: "2025-04-03 07:30:00",
        category: ["technology"],
        creator: ["Mark Gurman"]
    ),
    Article(
        articleId: "mock-3",
        title: "This startup raised $200M to replace your company's entire IT team",
        link: "https://techcrunch.com",
        description: "A new startup called Alchemy AI just raised $200 million to build software that handles IT support, security monitoring, and network management — all with no humans needed. Big companies are already signing up. Investors say this could reshape how businesses manage their tech stack.",
        content: nil,
        imageUrl: nil,
        sourceId: "techcrunch",
        pubDate: "2025-04-02 14:00:00",
        category: ["business"],
        creator: ["Sarah Perez"]
    ),
    Article(
        articleId: "mock-4",
        title: "Amazon is cutting 14,000 jobs — and blaming AI for most of it",
        link: "https://reuters.com",
        description: "Amazon announced it's laying off 14,000 employees across its logistics and operations divisions, citing automation and AI tools that now do the work faster. The layoffs are part of a broader shift across big tech where AI is replacing roles that used to take dozens of people.",
        content: nil,
        imageUrl: nil,
        sourceId: "reuters",
        pubDate: "2025-04-02 11:00:00",
        category: ["business"],
        creator: ["Reuters Staff"]
    ),
    Article(
        articleId: "mock-5",
        title: "Y Combinator's latest batch is the biggest ever — here's why",
        link: "https://ycombinator.com",
        description: "Y Combinator just graduated its largest batch of startups ever — 272 companies in one go. Most of them are building AI tools for healthcare, legal, and finance. The demo day pulled in over 3,000 investors, setting a new record for the famous startup accelerator.",
        content: nil,
        imageUrl: nil,
        sourceId: "ycombinator",
        pubDate: "2025-04-01 16:00:00",
        category: ["technology"],
        creator: ["YC Staff"]
    ),
    Article(
        articleId: "mock-6",
        title: "Google just cut the price of Google One storage in half",
        link: "https://google.com",
        description: "Google quietly slashed the price of its Google One storage plans by 50% this week. The 100GB plan now costs just $1 a month. Industry watchers say this is a direct shot at Apple iCloud and Microsoft OneDrive as the cloud storage war heats up heading into summer.",
        content: nil,
        imageUrl: nil,
        sourceId: "theverge",
        pubDate: "2025-04-01 10:00:00",
        category: ["technology"],
        creator: ["Nilay Patel"]
    ),
    Article(
        articleId: "mock-7",
        title: "Tesla's new $25K car is finally real — and shipping this fall",
        link: "https://tesla.com",
        description: "Tesla confirmed its long-promised $25,000 electric car will start shipping in Q4 this year. The vehicle skips fancy screens and fancy features to keep costs low. Elon Musk says the goal is to make an EV that any middle-class family can actually afford to buy.",
        content: nil,
        imageUrl: nil,
        sourceId: "electrek",
        pubDate: "2025-03-31 13:00:00",
        category: ["business"],
        creator: ["Fred Lambert"]
    ),
    Article(
        articleId: "mock-8",
        title: "Meta's AR glasses are coming — and they look surprisingly normal",
        link: "https://meta.com",
        description: "Meta showed off a new version of its augmented reality glasses that actually look like normal eyewear rather than something out of a sci-fi movie. The glasses can display notifications, translate signs in real time, and take hands-free photos. A consumer version is expected by early 2026.",
        content: nil,
        imageUrl: nil,
        sourceId: "theverge",
        pubDate: "2025-03-30 09:00:00",
        category: ["technology"],
        creator: ["Alex Heath"]
    ),
    Article(
        articleId: "mock-9",
        title: "Stripe just became more valuable than most US banks",
        link: "https://stripe.com",
        description: "Payments company Stripe closed a new funding round that values it at $91 billion — more than most traditional US banks. The company processes over $1 trillion in payments a year and is now profitable. Founders say an IPO could happen as early as next year.",
        content: nil,
        imageUrl: nil,
        sourceId: "wsj",
        pubDate: "2025-03-29 14:00:00",
        category: ["business"],
        creator: ["WSJ Staff"]
    ),
    Article(
        articleId: "mock-10",
        title: "Microsoft is putting ChatGPT inside Excel — here's how it works",
        link: "https://microsoft.com",
        description: "Microsoft is rolling out a new AI feature inside Excel that lets you describe what you want in plain English and it builds the formula for you. No more googling how to write a VLOOKUP. The feature is live for Microsoft 365 subscribers starting this month.",
        content: nil,
        imageUrl: nil,
        sourceId: "microsoft",
        pubDate: "2025-03-28 10:00:00",
        category: ["technology"],
        creator: ["Tom Warren"]
    )
]
