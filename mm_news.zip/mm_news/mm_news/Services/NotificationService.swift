import UserNotifications
import Foundation

// MARK: - Local Push Notification Service
final class NotificationService {
    static let shared = NotificationService()
    private init() {}

    private let dailyID = "layman_daily_digest"

    /// Request permission — call once at startup.
    func requestPermission() async {
        _ = try? await UNUserNotificationCenter.current()
            .requestAuthorization(options: [.alert, .badge, .sound])
    }

    /// Returns true if the user has granted notification permission.
    func isAuthorized() async -> Bool {
        let settings = await UNUserNotificationCenter.current().notificationSettings()
        return settings.authorizationStatus == .authorized
    }

    /// Schedule a daily 9 AM digest. Safe to call multiple times (replaces previous).
    func scheduleDailyDigest(hour: Int = 9, minute: Int = 0) {
        UNUserNotificationCenter.current()
            .removePendingNotificationRequests(withIdentifiers: [dailyID])

        let content        = UNMutableNotificationContent()
        content.title      = "Your Daily Layman Brief 📰"
        content.body       = "Fresh stories in business, tech & startups are simplified and ready for you."
        content.sound      = .default

        var components     = DateComponents()
        components.hour    = hour
        components.minute  = minute

        let trigger  = UNCalendarNotificationTrigger(dateMatching: components, repeats: true)
        let request  = UNNotificationRequest(identifier: dailyID, content: content, trigger: trigger)
        UNUserNotificationCenter.current().add(request)
    }

    /// Schedule a "breaking news" one-shot notification (demo — fires in 5 s).
    func sendBreakingNewsDemo(headline: String) {
        let content       = UNMutableNotificationContent()
        content.title     = "Breaking on Layman"
        content.body      = headline
        content.sound     = .default

        let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 5, repeats: false)
        let request = UNNotificationRequest(
            identifier: UUID().uuidString,
            content: content,
            trigger: trigger
        )
        UNUserNotificationCenter.current().add(request)
    }

    func cancelAll() {
        UNUserNotificationCenter.current().removeAllPendingNotificationRequests()
    }
}
