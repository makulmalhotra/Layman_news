import Speech
import AVFoundation
import SwiftUI

// MARK: - Voice Input Service
@Observable
@MainActor
final class SpeechService: NSObject, SFSpeechRecognizerDelegate {

    var isRecording: Bool    = false
    var transcribedText: String = ""
    var permissionDenied: Bool  = false

    private var speechRecognizer  = SFSpeechRecognizer(locale: Locale(identifier: "en-US"))
    private var recognitionRequest: SFSpeechAudioBufferRecognitionRequest?
    private var recognitionTask:    SFSpeechRecognitionTask?
    private var audioEngine        = AVAudioEngine()

    override init() {
        super.init()
        speechRecognizer?.delegate = self
    }

    // MARK: - Request Permission
    func requestPermission() async -> Bool {
        let speechStatus = await withCheckedContinuation { cont in
            SFSpeechRecognizer.requestAuthorization { cont.resume(returning: $0) }
        }
        guard speechStatus == .authorized else { permissionDenied = true; return false }

        let micStatus = await AVAudioApplication.requestRecordPermission()
        if !micStatus { permissionDenied = true }
        return micStatus
    }

    // MARK: - Toggle recording
    func toggle() async {
        if isRecording { stopRecording(); return }

        // Check permission first
        let authorized = await requestPermission()
        guard authorized else { return }

        startRecording()
    }

    // MARK: - Start
    private func startRecording() {
        // Reset any previous task
        recognitionTask?.cancel()
        recognitionTask = nil
        transcribedText  = ""

        let audioSession = AVAudioSession.sharedInstance()
        try? audioSession.setCategory(.record, mode: .measurement, options: .duckOthers)
        try? audioSession.setActive(true, options: .notifyOthersOnDeactivation)

        recognitionRequest = SFSpeechAudioBufferRecognitionRequest()
        guard let recognitionRequest else { return }
        recognitionRequest.shouldReportPartialResults = true

        let inputNode = audioEngine.inputNode
        recognitionTask = speechRecognizer?.recognitionTask(with: recognitionRequest) { [weak self] result, error in
            guard let self else { return }
            Task { @MainActor in
                if let result {
                    self.transcribedText = result.bestTranscription.formattedString
                }
                if error != nil || result?.isFinal == true {
                    self.stopRecording()
                }
            }
        }

        let format = inputNode.outputFormat(forBus: 0)
        inputNode.installTap(onBus: 0, bufferSize: 1024, format: format) { [weak self] buffer, _ in
            self?.recognitionRequest?.append(buffer)
        }

        audioEngine.prepare()
        try? audioEngine.start()
        isRecording = true
    }

    // MARK: - Stop
    func stopRecording() {
        audioEngine.stop()
        if audioEngine.inputNode.numberOfInputs > 0 {
            audioEngine.inputNode.removeTap(onBus: 0)
        }
        recognitionRequest?.endAudio()
        recognitionRequest = nil
        recognitionTask?.cancel()
        recognitionTask = nil
        try? AVAudioSession.sharedInstance().setActive(false, options: .notifyOthersOnDeactivation)
        isRecording = false
    }

    // SFSpeechRecognizerDelegate
    nonisolated func speechRecognizer(_ speechRecognizer: SFSpeechRecognizer, availabilityDidChange available: Bool) {}
}
