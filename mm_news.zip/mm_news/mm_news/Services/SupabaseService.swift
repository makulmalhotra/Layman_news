import Foundation

/// Handles all Supabase REST API calls (no SDK — pure URLSession).
actor SupabaseService {

    private let baseURL: String
    private let anonKey: String
    private let session: URLSession

    init(baseURL: String = AppConfig.supabaseURL,
         anonKey: String = AppConfig.supabaseAnonKey) {
        self.baseURL = baseURL
        self.anonKey = anonKey
        self.session = URLSession.shared
    }

    // MARK: - Auth

    func signUp(email: String, password: String) async throws -> AuthResponse {
        let url = URL(string: "\(baseURL)/auth/v1/signup")!
        var req = URLRequest(url: url)
        req.httpMethod = "POST"
        req.setValue("application/json",   forHTTPHeaderField: "Content-Type")
        req.setValue(anonKey,              forHTTPHeaderField: "apikey")
        req.httpBody = try JSONEncoder().encode(AuthRequest(email: email, password: password))
        return try await perform(req, as: AuthResponse.self)
    }

    func signIn(email: String, password: String) async throws -> AuthResponse {
        let url = URL(string: "\(baseURL)/auth/v1/token?grant_type=password")!
        var req = URLRequest(url: url)
        req.httpMethod = "POST"
        req.setValue("application/json",   forHTTPHeaderField: "Content-Type")
        req.setValue(anonKey,              forHTTPHeaderField: "apikey")
        req.httpBody = try JSONEncoder().encode(AuthRequest(email: email, password: password))
        return try await perform(req, as: AuthResponse.self)
    }

    func signOut(accessToken: String) async throws {
        let url = URL(string: "\(baseURL)/auth/v1/logout")!
        var req = URLRequest(url: url)
        req.httpMethod = "POST"
        req.setValue("application/json",  forHTTPHeaderField: "Content-Type")
        req.setValue(anonKey,             forHTTPHeaderField: "apikey")
        req.setValue("Bearer \(accessToken)", forHTTPHeaderField: "Authorization")
        let (_, _) = try await session.data(for: req)
    }

    // MARK: - Saved Articles

    func getSavedArticles(accessToken: String, userId: String) async throws -> [SavedArticleDB] {
        let url = URL(string: "\(baseURL)/rest/v1/saved_articles?user_id=eq.\(userId)&select=*&order=created_at.desc")!
        var req = URLRequest(url: url)
        req.setValue("application/json",       forHTTPHeaderField: "Content-Type")
        req.setValue(anonKey,                  forHTTPHeaderField: "apikey")
        req.setValue("Bearer \(accessToken)",  forHTTPHeaderField: "Authorization")
        return try await perform(req, as: [SavedArticleDB].self)
    }

    func saveArticle(_ article: Article, accessToken: String, userId: String) async throws {
        let url = URL(string: "\(baseURL)/rest/v1/saved_articles")!
        var req = URLRequest(url: url)
        req.httpMethod = "POST"
        req.setValue("application/json",       forHTTPHeaderField: "Content-Type")
        req.setValue(anonKey,                  forHTTPHeaderField: "apikey")
        req.setValue("Bearer \(accessToken)",  forHTTPHeaderField: "Authorization")
        req.setValue("return=minimal",         forHTTPHeaderField: "Prefer")

        let body = SavedArticleDB(
            id: nil,
            userId: userId,
            articleId: article.id,
            title: article.title,
            link: article.link,
            imageUrl: article.imageUrl,
            sourceId: article.sourceId,
            pubDate: article.pubDate,
            createdAt: nil
        )
        req.httpBody = try JSONEncoder().encode(body)
        let (_, _) = try await session.data(for: req)
    }

    func deleteArticle(articleId: String, accessToken: String, userId: String) async throws {
        let url = URL(string: "\(baseURL)/rest/v1/saved_articles?article_id=eq.\(articleId)&user_id=eq.\(userId)")!
        var req = URLRequest(url: url)
        req.httpMethod = "DELETE"
        req.setValue("application/json",       forHTTPHeaderField: "Content-Type")
        req.setValue(anonKey,                  forHTTPHeaderField: "apikey")
        req.setValue("Bearer \(accessToken)",  forHTTPHeaderField: "Authorization")
        let (_, _) = try await session.data(for: req)
    }

    // MARK: - Helper
    private func perform<T: Decodable>(_ request: URLRequest, as type: T.Type) async throws -> T {
        let (data, response) = try await session.data(for: request)
        if let http = response as? HTTPURLResponse, http.statusCode >= 400 {
            let msg = String(data: data, encoding: .utf8) ?? "Unknown error"
            throw SupabaseError.httpError(http.statusCode, msg)
        }
        return try JSONDecoder().decode(type, from: data)
    }
}

enum SupabaseError: LocalizedError {
    case httpError(Int, String)

    var errorDescription: String? {
        switch self {
        case .httpError(let code, let msg):
            if msg.contains("invalid") && msg.contains("email") { return "Please enter a valid email address." }
            if msg.contains("Email not confirmed")               { return "Check your email and click the confirmation link first." }
            if msg.contains("Invalid login")                     { return "Wrong email or password." }
            if msg.contains("already registered")                { return "Email already registered. Try signing in." }
            if code == 400 { return "Invalid email or password." }
            if code == 422 { return "Email already registered. Try signing in." }
            if code == 429 { return "Too many attempts. Wait a moment and try again." }
            return "Error \(code): \(msg)"
        }
    }
}
