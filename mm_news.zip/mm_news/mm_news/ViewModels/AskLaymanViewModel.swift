import SwiftUI

@Observable
@MainActor
final class AskLaymanViewModel {

    // MARK: - State
    var messages: [ChatMessage]       = []
    var suggestions: [String]         = []
    var inputText: String             = ""
    var isTyping: Bool                = false          // bot is "typing"
    var isLoadingSuggestions: Bool    = false
    var errorMessage: String?         = nil

    private let gemini  = GeminiService()
    private(set) var article: Article

    init(article: Article) {
        self.article = article
        // Add initial bot greeting
        messages.append(ChatMessage(
            role: .bot,
            content: "Hi, I'm Layman! What can I answer for you?"
        ))
    }

    // MARK: - Load suggestions on appear
    func loadSuggestions() async {
        guard suggestions.isEmpty else { return }
        isLoadingSuggestions = true
        do {
            suggestions = try await gemini.generateSuggestions(for: article)
        } catch {
            // Use fallback — no need to surface this error
            suggestions = ["What is the main takeaway here?",
                           "How does this affect regular people?",
                           "Why is this news important now?"]
        }
        isLoadingSuggestions = false
    }

    // MARK: - Send a message
    func send(text: String) async {
        let trimmed = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty, !isTyping else { return }
        inputText = ""
        errorMessage = nil

        // Add user message
        let userMsg = ChatMessage(role: .user, content: trimmed)
        withAnimation(.easeOut(duration: 0.25)) {
            messages.append(userMsg)
        }

        // Show typing indicator
        isTyping = true

        do {
            let reply = try await gemini.chat(
                question: trimmed,
                article: article,
                history: messages
            )
            withAnimation(.easeOut(duration: 0.3)) {
                isTyping = false
                messages.append(ChatMessage(role: .bot, content: reply))
            }
        } catch {
            isTyping = false
            let msg: String
            let desc = error.localizedDescription
            if desc.contains("429") || desc.contains("quota") || desc.contains("RESOURCE_EXHAUSTED") {
                msg = "Quota limit reached on your Gemini API key. Create a new key at aistudio.google.com → Get API key → Create in new project."
            } else if desc.contains("403") || desc.contains("API key") {
                msg = "Invalid Gemini API key. Check Config.swift."
            } else {
                msg = "Error: \(desc)"
            }
            withAnimation {
                messages.append(ChatMessage(role: .bot, content: msg))
            }
        }
    }

    // MARK: - Tap a suggestion chip
    func selectSuggestion(_ text: String) async {
        suggestions = []   // hide chips after first interaction
        await send(text: text)
    }
}
