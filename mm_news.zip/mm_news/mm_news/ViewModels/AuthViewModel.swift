import SwiftUI

@Observable
@MainActor
final class AuthViewModel {

    // MARK: - Form state
    var email: String    = ""
    var password: String = ""
    var isSignUp: Bool   = false

    // MARK: - UI state
    var isLoading: Bool    = false
    var errorMessage: String? = nil
    var isAuthenticated: Bool = false
    var currentSession: StoredSession? = nil

    private let supabase = SupabaseService()

    // MARK: - Session restore
    func restoreSession() {
        if let session = KeychainHelper.loadSession() {
            currentSession   = session
            isAuthenticated  = true
        }
    }

    // MARK: - Sign Up
    func signUp() async {
        guard validate() else { return }
        isLoading    = true
        errorMessage = nil
        if isDemoMode {
            await mockDelay()
            storeMockSession()
        } else {
            do {
                let response = try await supabase.signUp(email: email, password: password)
                storeSession(from: response)
            } catch {
                errorMessage = error.localizedDescription
            }
        }
        isLoading = false
    }

    // MARK: - Sign In
    func signIn() async {
        guard validate() else { return }
        isLoading    = true
        errorMessage = nil
        if isDemoMode {
            await mockDelay()
            storeMockSession()
        } else {
            do {
                let response = try await supabase.signIn(email: email, password: password)
                storeSession(from: response)
            } catch {
                errorMessage = error.localizedDescription
            }
        }
        isLoading = false
    }

    // MARK: - Sign Out
    func signOut() async {
        if !isDemoMode, let session = currentSession {
            try? await supabase.signOut(accessToken: session.accessToken)
        }
        KeychainHelper.deleteSession()
        currentSession   = nil
        isAuthenticated  = false
        email            = ""
        password         = ""
    }

    // MARK: - Demo / mock helpers
    /// True when Supabase credentials are still placeholders.
    private var isDemoMode: Bool {
        AppConfig.supabaseURL.contains("YOUR_PROJECT_ID")
    }

    private func mockDelay() async {
        try? await Task.sleep(nanoseconds: 800_000_000) // 0.8 s fake network
    }

    private func storeMockSession() {
        let session = StoredSession(
            accessToken:  "demo_access_token",
            refreshToken: "demo_refresh_token",
            userId:       "demo-user-\(UUID().uuidString.prefix(8))",
            email:        email
        )
        KeychainHelper.saveSession(session)
        currentSession  = session
        isAuthenticated = true
    }

    // MARK: - Primary action (sign up OR sign in)
    func authenticate() async {
        if isSignUp { await signUp() } else { await signIn() }
    }

    // MARK: - Helpers
    private func validate() -> Bool {
        errorMessage = nil
        guard !email.trimmingCharacters(in: .whitespaces).isEmpty else {
            errorMessage = "Please enter your email address."
            return false
        }
        guard email.contains("@"), email.contains(".") else {
            errorMessage = "Please enter a valid email address."
            return false
        }
        guard password.count >= 6 else {
            errorMessage = "Password must be at least 6 characters."
            return false
        }
        return true
    }

    private func storeSession(from response: AuthResponse) {
        guard
            let accessToken  = response.accessToken,
            let refreshToken = response.refreshToken,
            let user         = response.user
        else {
            // Supabase returned no token — email confirmation required
            errorMessage = "Check your email and click the confirmation link, then sign in."
            return
        }
        let session = StoredSession(
            accessToken:  accessToken,
            refreshToken: refreshToken,
            userId:       user.id,
            email:        user.email ?? email
        )
        KeychainHelper.saveSession(session)
        currentSession   = session
        isAuthenticated  = true
    }
}
