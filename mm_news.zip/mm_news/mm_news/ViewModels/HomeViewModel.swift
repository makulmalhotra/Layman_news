import SwiftUI

@Observable
@MainActor
final class HomeViewModel {

    // MARK: - Article data
    var featuredArticles: [Article]   = []
    var todaysPicks: [Article]        = []
    var allArticles: [Article]        = []

    // MARK: - Saved state
    var savedArticleIds: Set<String>  = []
    var savedArticleObjects: [Article] = []   // full objects, persisted locally + Supabase

    // MARK: - UI state
    var isLoading: Bool       = false
    var errorMessage: String? = nil
    var searchText: String    = ""

    // Non-featured articles (everything after the carousel 5) — used for "View All"
    var nonFeaturedArticles: [Article] {
        Array(allArticles.dropFirst(featuredArticles.count))
    }

    // MARK: - Filtered for search
    var filteredTodaysPicks: [Article] {
        if searchText.trimmingCharacters(in: .whitespaces).isEmpty { return todaysPicks }
        let q = searchText.lowercased()
        return nonFeaturedArticles.filter {
            $0.title.lowercased().contains(q) ||
            ($0.description?.lowercased().contains(q) ?? false)
        }
    }

    // MARK: - Saved articles list
    // Uses fresh feed article if available, otherwise uses locally stored object
    var savedArticles: [Article] {
        savedArticleIds.compactMap { id in
            allArticles.first(where: { $0.id == id }) ??
            savedArticleObjects.first(where: { $0.id == id })
        }
    }

    private let newsService      = NewsService()
    private let supabase         = SupabaseService()
    private var currentSession: StoredSession?

    private let savedIdsKey     = "layman_saved_article_ids"
    private let savedObjsKey    = "layman_saved_article_objects"

    // MARK: - Init — restore saved state from local storage immediately
    init() {
        if let ids = UserDefaults.standard.array(forKey: "layman_saved_article_ids") as? [String] {
            savedArticleIds = Set(ids)
        }
        if let data = UserDefaults.standard.data(forKey: "layman_saved_article_objects"),
           let articles = try? JSONDecoder().decode([Article].self, from: data) {
            savedArticleObjects = articles
        }
        // Realtime sync: refresh saved articles when app returns to foreground
        NotificationCenter.default.addObserver(forName: .appBecameActive, object: nil, queue: .main) { [weak self] _ in
            guard let self else { return }
            Task { @MainActor in
                if self.currentSession != nil { await self.fetchSavedArticles() }
            }
        }
    }

    // MARK: - Configure with session (called from MainTabView)
    func configure(session: StoredSession) {
        self.currentSession = session
    }

    // MARK: - Fetch news articles
    func fetchArticles() async {
        isLoading    = true
        errorMessage = nil
        do {
            let articles     = try await newsService.fetchArticles()
            allArticles      = articles
            featuredArticles = Array(articles.prefix(5))
            todaysPicks      = Array(articles.dropFirst(5).prefix(5))
        } catch {
            errorMessage = "Couldn't load news: \(error.localizedDescription)"
        }
        isLoading = false
        if currentSession != nil { await fetchSavedArticles() }
    }

    // MARK: - Toggle save / unsave
    func toggleSave(article: Article) async {
        if savedArticleIds.contains(article.id) {
            // Unsave
            savedArticleIds.remove(article.id)
            savedArticleObjects.removeAll { $0.id == article.id }
            if let session = currentSession {
                try? await supabase.deleteArticle(
                    articleId: article.id,
                    accessToken: session.accessToken,
                    userId: session.userId
                )
            }
        } else {
            // Save
            savedArticleIds.insert(article.id)
            if !savedArticleObjects.contains(where: { $0.id == article.id }) {
                savedArticleObjects.append(article)
            }
            if let session = currentSession {
                try? await supabase.saveArticle(
                    article,
                    accessToken: session.accessToken,
                    userId: session.userId
                )
            }
        }
        persistLocally()
    }

    func isSaved(_ article: Article) -> Bool { savedArticleIds.contains(article.id) }

    // MARK: - Sync saved articles from Supabase
    func fetchSavedArticles() async {
        guard let session = currentSession else { return }
        guard let saved = try? await supabase.getSavedArticles(
            accessToken: session.accessToken,
            userId: session.userId
        ) else { return }   // keep local data on failure

        // Rebuild from Supabase — it is the source of truth when logged in
        savedArticleIds = Set(saved.map { $0.articleId })
        // Merge: prefer fresh allArticles data, fallback to Supabase stored data
        let fromSupabase = saved.map { $0.toArticle() }
        var merged: [Article] = []
        for dbArt in fromSupabase {
            if let fresh = allArticles.first(where: { $0.id == dbArt.id }) {
                merged.append(fresh)
            } else {
                merged.append(dbArt)
            }
        }
        savedArticleObjects = merged
        persistLocally()
    }

    // MARK: - Persist to UserDefaults
    private func persistLocally() {
        UserDefaults.standard.set(Array(savedArticleIds), forKey: savedIdsKey)
        if let data = try? JSONEncoder().encode(savedArticleObjects) {
            UserDefaults.standard.set(data, forKey: savedObjsKey)
        }
    }
}
