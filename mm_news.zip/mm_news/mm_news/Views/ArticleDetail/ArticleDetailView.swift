import SwiftUI
import SafariServices

// MARK: - Article Detail Screen (Screen 4)
struct ArticleDetailView: View {
    let article: Article
    var isSaved: Bool
    var onSave: () -> Void
    var onBack: () -> Void

    @State private var currentCard: Int = 0
    @State private var showSafari: Bool = false
    @State private var showShareSheet: Bool = false
    @State private var saveAnimating: Bool = false
    @State private var showAskLayman: Bool = false

    private var cards: [String] { article.contentCards }

    var body: some View {
        ZStack(alignment: .bottom) {
            Color.laymanBackground.ignoresSafeArea()

            VStack(spacing: 0) {
                topBar
                scrollContent
            }
            .blur(radius: showAskLayman ? 8 : 0)
            .animation(.easeInOut(duration: 0.3), value: showAskLayman)

            // "Ask Layman" button fixed at bottom
            askLaymanButton
                .opacity(showAskLayman ? 0 : 1)
                .animation(.easeInOut(duration: 0.2), value: showAskLayman)
        }
        .onAppear { StreakManager.shared.recordRead() }
        .sheet(isPresented: $showSafari) {
            if let urlStr = article.link, let url = URL(string: urlStr) {
                SafariView(url: url)
                    .ignoresSafeArea()
            }
        }
        .sheet(isPresented: $showShareSheet) {
            if let urlStr = article.link {
                ShareSheet(items: [article.title, urlStr])
            }
        }
        .sheet(isPresented: $showAskLayman) {
            AskLaymanView(article: article, onDismiss: { showAskLayman = false })
                .presentationDetents([.fraction(0.70), .large])
                .presentationDragIndicator(.visible)
                .presentationCornerRadius(28)
                .presentationBackground(Color.laymanBackground)
        }
    }

    // MARK: - Top bar
    private var topBar: some View {
        HStack(spacing: 0) {
            // Back
            Button(action: onBack) {
                Image(systemName: "chevron.left")
                    .font(.system(size: 18, weight: .semibold))
                    .foregroundColor(Color.laymanText)
                    .frame(width: 44, height: 44)
            }

            Spacer()

            // Link
            Button {
                UIImpactFeedbackGenerator(style: .light).impactOccurred()
                showSafari = true
            } label: {
                Image(systemName: "link")
                    .font(.system(size: 18, weight: .medium))
                    .foregroundColor(Color.laymanText)
                    .frame(width: 44, height: 44)
            }

            // Bookmark
            Button {
                UIImpactFeedbackGenerator(style: .medium).impactOccurred()
                withAnimation(.spring(response: 0.3, dampingFraction: 0.5)) { saveAnimating = true }
                onSave()
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.35) { saveAnimating = false }
            } label: {
                Image(systemName: isSaved ? "bookmark.fill" : "bookmark")
                    .font(.system(size: 18, weight: .medium))
                    .foregroundColor(isSaved ? Color.laymanOrange : Color.laymanText)
                    .scaleEffect(saveAnimating ? 1.3 : 1.0)
                    .frame(width: 44, height: 44)
            }

            // Share
            Button {
                UIImpactFeedbackGenerator(style: .light).impactOccurred()
                showShareSheet = true
            } label: {
                Image(systemName: "square.and.arrow.up")
                    .font(.system(size: 18, weight: .medium))
                    .foregroundColor(Color.laymanText)
                    .frame(width: 44, height: 44)
            }
        }
        .padding(.horizontal, 8)
        .padding(.top, 8)
        .background(Color.laymanBackground)
    }

    // MARK: - Scrollable content
    private var scrollContent: some View {
        ScrollView(showsIndicators: false) {
            VStack(alignment: .leading, spacing: 0) {
                headlineSection
                articleImageSection
                contentCardsSection
                Spacer().frame(height: 100) // space for Ask Layman button
            }
        }
    }

    // MARK: - Bold 2-line headline
    private var headlineSection: some View {
        Text(article.title)
            .font(.system(size: 22, weight: .bold))
            .foregroundColor(Color.laymanText)
            .lineLimit(2)
            .fixedSize(horizontal: false, vertical: true)
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(.horizontal, 20)
            .padding(.top, 16)
            .padding(.bottom, 16)
    }

    // MARK: - Rounded article image (matches home screen card style)
    private var articleImageSection: some View {
        RoundedRectangle(cornerRadius: 16)
            .fill(Color.laymanDarkOrange)
            .frame(maxWidth: .infinity)
            .frame(height: 220)
            .overlay {
                if let urlStr = article.imageUrl, let url = URL(string: urlStr) {
                    AsyncImage(url: url) { phase in
                        switch phase {
                        case .success(let img):
                            img.resizable()
                                .scaledToFill()
                                .frame(maxWidth: .infinity, maxHeight: .infinity)
                        case .failure, .empty:
                            articleImagePlaceholder
                        @unknown default:
                            articleImagePlaceholder
                        }
                    }
                } else {
                    articleImagePlaceholder
                }
            }
            .clipShape(RoundedRectangle(cornerRadius: 16))
            .shadow(color: Color.black.opacity(0.10), radius: 8, x: 0, y: 4)
            .padding(.horizontal, 20)
            .padding(.bottom, 24)
    }

    private var articleImagePlaceholder: some View {
        LinearGradient(
            colors: [Color.laymanOrange.opacity(0.7), Color.laymanDarkOrange],
            startPoint: .topLeading,
            endPoint: .bottomTrailing
        )
        .overlay(
            Image(systemName: "newspaper")
                .font(.system(size: 44))
                .foregroundColor(.white.opacity(0.6))
        )
    }

    // MARK: - 3 swipeable content cards
    private var contentCardsSection: some View {
        VStack(spacing: 14) {
            // Swipeable cards
            TabView(selection: $currentCard) {
                ForEach(Array(cards.enumerated()), id: \.offset) { idx, text in
                    ContentCardView(text: text, index: idx, total: cards.count)
                        .tag(idx)
                }
            }
            .tabViewStyle(.page(indexDisplayMode: .never))
            .frame(height: 190)
            .padding(.horizontal, 20)

            // Page dots
            PageDots(count: cards.count, current: currentCard)
                .padding(.bottom, 8)
        }
    }

    // MARK: - Ask Layman fixed button
    private var askLaymanButton: some View {
        VStack(spacing: 0) {
            // Fade gradient above button
            LinearGradient(
                colors: [Color.laymanBackground.opacity(0), Color.laymanBackground],
                startPoint: .top,
                endPoint: .bottom
            )
            .frame(height: 32)

            Button {
                UIImpactFeedbackGenerator(style: .medium).impactOccurred()
                showAskLayman = true
            } label: {
                HStack(spacing: 8) {
                    Image(systemName: "bubble.left.and.bubble.right.fill")
                        .font(.system(size: 16, weight: .semibold))
                    Text("Ask Layman")
                        .font(.system(size: 16, weight: .semibold))
                }
                .foregroundColor(.white)
                .frame(maxWidth: .infinity)
                .frame(height: 52)
                .background(
                    RoundedRectangle(cornerRadius: 26)
                        .fill(Color.laymanOrange)
                        .shadow(color: Color.laymanOrange.opacity(0.5), radius: 10, x: 0, y: 4)
                )
            }
            .buttonStyle(ScaleButtonStyle(scale: 0.97))
            .padding(.horizontal, 28)
            .padding(.bottom, 36)
            .background(Color.laymanBackground)
        }
    }
}

// MARK: - Content card (one of 3 swipeable layman-terms cards)
private struct ContentCardView: View {
    let text: String
    let index: Int
    let total: Int

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            // Card counter label
            HStack {
                Text("\(index + 1) of \(total)")
                    .font(.system(size: 11, weight: .bold))
                    .foregroundColor(Color.laymanOrange)
                    .kerning(0.5)
                Spacer()
            }

            // Content text — 28-35 words filling ~6 lines
            Text(text)
                .font(.system(size: 15, weight: .regular))
                .foregroundColor(Color.laymanText)
                .lineSpacing(5)
                .frame(maxWidth: .infinity, alignment: .leading)
                .fixedSize(horizontal: false, vertical: false)
                .lineLimit(6)

            Spacer(minLength: 0)
        }
        .padding(20)
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(
            RoundedRectangle(cornerRadius: 16)
                .fill(Color.laymanCard)
                .shadow(color: Color.black.opacity(0.12), radius: 8, x: 0, y: 3)
        )
    }
}

// MARK: - In-app Safari wrapper
struct SafariView: UIViewControllerRepresentable {
    let url: URL

    func makeUIViewController(context: Context) -> SFSafariViewController {
        SFSafariViewController(url: url)
    }
    func updateUIViewController(_ uiViewController: SFSafariViewController, context: Context) {}
}

// MARK: - Share sheet wrapper
struct ShareSheet: UIViewControllerRepresentable {
    let items: [Any]

    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: items, applicationActivities: nil)
    }
    func updateUIViewController(_ uiViewController: UIActivityViewController, context: Context) {}
}
