import SwiftUI
import Combine

// MARK: - Ask Layman Chat Sheet
struct AskLaymanView: View {
    let article: Article
    var onDismiss: () -> Void

    @State private var viewModel: AskLaymanViewModel
    @State private var speechService = SpeechService()
    @FocusState private var inputFocused: Bool

    init(article: Article, onDismiss: @escaping () -> Void) {
        self.article   = article
        self.onDismiss = onDismiss
        self._viewModel = State(initialValue: AskLaymanViewModel(article: article))
    }

    var body: some View {
        ZStack(alignment: .bottom) {
            chatScrollView
            inputBar
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .task { await viewModel.loadSuggestions() }
        .onTapGesture { inputFocused = false }
        .onChange(of: speechService.transcribedText) { _, text in
            if !text.isEmpty { viewModel.inputText = text }
        }
    }

    // MARK: - Scrollable chat area
    private var chatScrollView: some View {
        ScrollViewReader { proxy in
            ScrollView(showsIndicators: false) {
                LazyVStack(alignment: .leading, spacing: 14) {
                    ForEach(viewModel.messages) { msg in
                        MessageBubble(message: msg)
                            .id(msg.id)
                    }

                    if !viewModel.suggestions.isEmpty || viewModel.isLoadingSuggestions {
                        suggestionChips
                            .id("suggestions")
                    }

                    if viewModel.isTyping {
                        TypingIndicator()
                            .id("typing")
                            .transition(.opacity)
                    }

                    Color.clear.frame(height: 80).id("bottom")
                }
                .padding(.horizontal, 16)
                .padding(.top, 20)
                .padding(.bottom, 90)
                .animation(.spring(response: 0.45, dampingFraction: 0.75), value: viewModel.messages.count)
                .animation(.spring(response: 0.35, dampingFraction: 0.8), value: viewModel.isTyping)
            }
            .onChange(of: viewModel.messages.count) { _, _ in
                withAnimation { proxy.scrollTo("bottom", anchor: .bottom) }
            }
            .onChange(of: viewModel.isTyping) { _, typing in
                if typing { withAnimation { proxy.scrollTo("typing", anchor: .bottom) } }
            }
        }
    }

    // MARK: - Suggestion chips
    private var suggestionChips: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Question Suggestions:")
                .font(.system(size: 12, weight: .medium))
                .foregroundColor(Color.laymanSubtext)

            if viewModel.isLoadingSuggestions {
                VStack(alignment: .leading, spacing: 8) {
                    ForEach(0..<3, id: \.self) { _ in
                        Capsule()
                            .fill(Color.laymanOrange.opacity(0.15))
                            .frame(height: 40)
                    }
                }
            } else {
                VStack(alignment: .leading, spacing: 8) {
                    ForEach(viewModel.suggestions, id: \.self) { suggestion in
                        Button {
                            UIImpactFeedbackGenerator(style: .medium).impactOccurred()
                            Task { await viewModel.selectSuggestion(suggestion) }
                        } label: {
                            Text(suggestion)
                                .frame(maxWidth: .infinity, alignment: .leading)
                                .font(.system(size: 14, weight: .medium))
                                .foregroundColor(.white)
                                .padding(.horizontal, 18)
                                .padding(.vertical, 12)
                                .background(Capsule().fill(Color.laymanDarkOrange))
                        }
                        .buttonStyle(ScaleButtonStyle())
                    }
                }
            }
        }
        .transition(.opacity.combined(with: .scale(scale: 0.97, anchor: .leading)))
    }

    // MARK: - Bottom input bar
    private var inputBar: some View {
        VStack(spacing: 0) {
            Divider().opacity(0.15)
            HStack(spacing: 10) {
                HStack(spacing: 8) {
                    TextField("Type your question...", text: $viewModel.inputText, axis: .vertical)
                        .font(.system(size: 15))
                        .foregroundColor(Color.laymanText)
                        .lineLimit(1...4)
                        .focused($inputFocused)
                        .submitLabel(.send)
                        .onSubmit {
                            Task { await viewModel.send(text: viewModel.inputText) }
                        }

                    Button {
                        UIImpactFeedbackGenerator(style: .light).impactOccurred()
                        Task { await speechService.toggle() }
                    } label: {
                        Image(systemName: speechService.isRecording ? "waveform" : "mic")
                            .font(.system(size: 18))
                            .foregroundColor(speechService.isRecording ? Color.laymanOrange : Color.laymanSubtext)
                            .symbolEffect(.pulse, isActive: speechService.isRecording)
                    }
                }
                .padding(.horizontal, 16)
                .padding(.vertical, 12)
                .background(Color.laymanSurface)
                .clipShape(Capsule())

                Button {
                    UIImpactFeedbackGenerator(style: .medium).impactOccurred()
                    inputFocused = false
                    Task { await viewModel.send(text: viewModel.inputText) }
                } label: {
                    ZStack {
                        Circle()
                            .fill(viewModel.inputText.trimmingCharacters(in: .whitespaces).isEmpty
                                  ? Color.laymanSubtext.opacity(0.3)
                                  : Color.laymanOrange)
                            .frame(width: 46, height: 46)
                        Image(systemName: "paperplane.fill")
                            .font(.system(size: 16, weight: .semibold))
                            .foregroundColor(.white)
                            .offset(x: 1)
                    }
                }
                .disabled(viewModel.inputText.trimmingCharacters(in: .whitespaces).isEmpty || viewModel.isTyping)
                .buttonStyle(ScaleButtonStyle(scale: 0.88))
                .animation(.easeInOut(duration: 0.15), value: viewModel.inputText.isEmpty)
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 12)
            .background(Color.laymanBackground)
            .padding(.bottom, 8)
        }
    }
}

// MARK: - Message bubble
private struct MessageBubble: View {
    let message: ChatMessage
    @State private var appeared = false

    var body: some View {
        HStack(alignment: .top, spacing: 10) {
            if message.role == .bot {
                botIcon
                botBubble
                Spacer(minLength: 40)
            } else {
                Spacer(minLength: 40)
                userBubble
            }
        }
        .scaleEffect(appeared ? 1 : 0.88)
        .opacity(appeared ? 1 : 0)
        .onAppear {
            withAnimation(.spring(response: 0.4, dampingFraction: 0.7)) { appeared = true }
        }
    }

    private var botIcon: some View {
        ZStack {
            Circle()
                .fill(
                    LinearGradient(
                        colors: [Color.laymanOrange, Color.laymanDarkOrange],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    )
                )
                .frame(width: 34, height: 34)
            Image(systemName: "sparkles")
                .font(.system(size: 14, weight: .semibold))
                .foregroundColor(.white)
        }
        .shadow(color: Color.laymanOrange.opacity(0.4), radius: 4, x: 0, y: 2)
    }

    private var botBubble: some View {
        Text(message.content)
            .font(.system(size: 15))
            .foregroundColor(Color.laymanText)
            .padding(.horizontal, 14)
            .padding(.vertical, 12)
            .background(
                RoundedRectangle(cornerRadius: 16, style: .continuous)
                    .fill(Color.laymanCard)
            )
    }

    private var userBubble: some View {
        Text(message.content)
            .font(.system(size: 15))
            .foregroundColor(.white)
            .padding(.horizontal, 14)
            .padding(.vertical, 12)
            .background(
                RoundedRectangle(cornerRadius: 16, style: .continuous)
                    .fill(Color.laymanOrange)
            )
    }
}

// MARK: - Animated typing indicator
private struct TypingIndicator: View {
    @State private var phase: Int = 0
    private let timer = Timer.publish(every: 0.4, on: .main, in: .common).autoconnect()

    var body: some View {
        HStack(alignment: .top, spacing: 10) {
            ZStack {
                Circle()
                    .fill(
                        LinearGradient(
                            colors: [Color.laymanOrange, Color.laymanDarkOrange],
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        )
                    )
                    .frame(width: 34, height: 34)
                Image(systemName: "sparkles")
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundColor(.white)
            }
            .shadow(color: Color.laymanOrange.opacity(0.4), radius: 4, x: 0, y: 2)

            HStack(spacing: 5) {
                ForEach(0..<3, id: \.self) { i in
                    Circle()
                        .fill(Color.laymanSubtext.opacity(phase == i ? 1 : 0.3))
                        .frame(width: 7, height: 7)
                        .offset(y: phase == i ? -3 : 0)
                        .animation(.spring(response: 0.3, dampingFraction: 0.5).delay(Double(i) * 0.1), value: phase)
                }
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 14)
            .background(
                RoundedRectangle(cornerRadius: 16)
                    .fill(Color.laymanCard)
            )

            Spacer()
        }
        .onReceive(timer) { _ in
            phase = (phase + 1) % 3
        }
    }
}

#Preview {
    AskLaymanView(
        article: Article(
            articleId: "preview",
            title: "OpenAI's new model beats every benchmark out there",
            link: nil,
            description: "OpenAI just dropped GPT-5 and it's outperforming every other AI model on the planet.",
            content: nil,
            imageUrl: nil,
            sourceId: "techcrunch",
            pubDate: nil,
            category: nil,
            creator: nil
        ),
        onDismiss: {}
    )
}
