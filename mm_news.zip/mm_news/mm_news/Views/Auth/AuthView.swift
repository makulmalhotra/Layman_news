import SwiftUI

// MARK: - Auth Screen (Screen 2)
struct AuthView: View {
    @Bindable var viewModel: AuthViewModel

    @State private var showPassword: Bool = false
    @FocusState private var focusedField: AuthField?
    @State private var emailTouched: Bool = false
    @State private var passwordTouched: Bool = false

    enum AuthField { case email, password }

    private var emailError: String? {
        guard emailTouched, !viewModel.email.isEmpty else { return nil }
        let valid = viewModel.email.contains("@") && viewModel.email.contains(".")
        return valid ? nil : "Enter a valid email address"
    }

    private var passwordError: String? {
        guard passwordTouched, !viewModel.password.isEmpty else { return nil }
        return viewModel.password.count >= 6 ? nil : "Password must be at least 6 characters"
    }

    var body: some View {
        ZStack {
            Color.laymanBackground.ignoresSafeArea()

            ScrollView(showsIndicators: false) {
                VStack(spacing: 0) {
                    headerSection
                    formSection
                    Spacer(minLength: 40)
                }
                .padding(.horizontal, 28)
            }
        }
        .onTapGesture { focusedField = nil }
    }

    // MARK: - Header
    private var headerSection: some View {
        VStack(spacing: 8) {
            Spacer().frame(height: 64)

            // Logo
            Text("Layman")
                .font(.system(size: 40, weight: .semibold, design: .serif))
                .frame(maxWidth: .infinity, alignment: .leading)
                .foregroundColor(Color.laymanText)

            // Tagline
            Text("Business, tech & startups\nmade simple")
                .frame(maxWidth: .infinity, alignment: .leading)
                .font(.system(size: 16, weight: .regular))
                .foregroundColor(Color.laymanSubtext)
                .lineSpacing(3)

            Spacer().frame(height: 40)

            // Mode title
            Text(viewModel.isSignUp ? "Create your account" : "Welcome back")
                .frame(maxWidth: .infinity, alignment: .leading)
                .font(.system(size: 26, weight: .bold))
                .foregroundColor(Color.laymanText)

            Spacer().frame(height: 4)

            Text(viewModel.isSignUp
                 ? "Sign up to start reading."
                 : "Sign in to continue reading.")
                .frame(maxWidth: .infinity, alignment: .leading)
                .font(.system(size: 15, weight: .regular))
                .foregroundColor(Color.laymanSubtext)

            Spacer().frame(height: 32)
        }
    }

    // MARK: - Form
    private var formSection: some View {
        VStack(spacing: 16) {
            // Email field
            VStack(alignment: .leading, spacing: 6) {
                AuthTextField(
                    placeholder: "you@example.com",
                    text: $viewModel.email,
                    icon: "envelope",
                    keyboardType: .emailAddress,
                    isSecure: false,
                    isFocused: focusedField == .email
                )
                .focused($focusedField, equals: .email)
                .submitLabel(.next)
                .onSubmit { focusedField = .password }
                .onChange(of: focusedField) { _, new in
                    if new != .email { emailTouched = true }
                }

                if let err = emailError {
                    Text(err)
                        .font(.system(size: 12, weight: .medium))
                        .foregroundColor(.red)
                        .padding(.leading, 4)
                        .transition(.opacity.combined(with: .move(edge: .top)))
                }
            }
            .animation(.easeInOut(duration: 0.18), value: emailError)

            // Password field
            VStack(alignment: .leading, spacing: 6) {
                AuthTextField(
                    placeholder: "Min. 6 characters",
                    text: $viewModel.password,
                    icon: "lock",
                    keyboardType: .default,
                    isSecure: !showPassword,
                    trailingButton: {
                        Button {
                            showPassword.toggle()
                        } label: {
                            Image(systemName: showPassword ? "eye.slash" : "eye")
                                .foregroundColor(Color.laymanSubtext)
                        }
                    },
                    isFocused: focusedField == .password
                )
                .focused($focusedField, equals: .password)
                .submitLabel(.done)
                .onSubmit {
                    focusedField = nil
                    Task { await viewModel.authenticate() }
                }
                .onChange(of: focusedField) { _, new in
                    if new != .password { passwordTouched = true }
                }

                if let err = passwordError {
                    Text(err)
                        .font(.system(size: 12, weight: .medium))
                        .foregroundColor(.red)
                        .padding(.leading, 4)
                        .transition(.opacity.combined(with: .move(edge: .top)))
                }
            }
            .animation(.easeInOut(duration: 0.18), value: passwordError)

            // Error message
            if let error = viewModel.errorMessage {
                HStack(spacing: 6) {
                    Image(systemName: "exclamationmark.circle.fill")
                        .foregroundColor(.red)
                    Text(error)
                        .font(.system(size: 13, weight: .medium))
                        .foregroundColor(.red)
                    Spacer()
                }
                .padding(.vertical, 2)
                .transition(.opacity.combined(with: .move(edge: .top)))
            }

            Spacer().frame(height: 8)

            // Demo mode banner
            if AppConfig.supabaseURL.contains("YOUR_PROJECT_ID") {
                HStack(spacing: 6) {
                    Image(systemName: "info.circle.fill")
                        .font(.system(size: 12))
                        .foregroundColor(Color.laymanOrange)
                    Text("Demo mode — any valid email & 6+ char password works")
                        .font(.system(size: 12))
                        .foregroundColor(Color.laymanSubtext)
                }
                .padding(.horizontal, 12)
                .padding(.vertical, 8)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(Color.laymanOrange.opacity(0.08))
                .clipShape(RoundedRectangle(cornerRadius: 8))
            }

            Spacer().frame(height: 8)

            // Primary CTA button
            Button {
                Task { await viewModel.authenticate() }
            } label: {
                ZStack {
                    RoundedRectangle(cornerRadius: 14)
                        .fill(Color.laymanOrange)
                    if viewModel.isLoading {
                        ProgressView()
                            .progressViewStyle(CircularProgressViewStyle(tint: .white))
                    } else {
                        Text(viewModel.isSignUp ? "Create Account" : "Sign In")
                            .frame(maxWidth: .infinity)
                            .font(.system(size: 17, weight: .semibold))
                            .foregroundColor(.white)
                    }
                }
                .frame(height: 54)
            }
            .disabled(viewModel.isLoading)

            Spacer().frame(height: 20)

            // Toggle mode
            Button {
                withAnimation(.easeInOut(duration: 0.2)) {
                    viewModel.isSignUp.toggle()
                    viewModel.errorMessage = nil
                    emailTouched = false
                    passwordTouched = false
                }
            } label: {
                HStack(spacing: 4) {
                    Text(viewModel.isSignUp
                         ? "Already have an account?"
                         : "Don't have an account?")
                        .font(.system(size: 14))
                        .foregroundColor(Color.laymanSubtext)
                    Text(viewModel.isSignUp ? "Sign In" : "Sign Up")
                        .font(.system(size: 14, weight: .semibold))
                        .foregroundColor(Color.laymanOrange)
                }
            }
        }
        .animation(.easeInOut(duration: 0.2), value: viewModel.errorMessage)
    }
}

// MARK: - Reusable Auth Text Field
struct AuthTextField<Trailing: View>: View {
    let placeholder: String
    @Binding var text: String
    let icon: String
    var keyboardType: UIKeyboardType = .default
    var isSecure: Bool = false
    @ViewBuilder var trailingButton: () -> Trailing
    var isFocused: Bool = false

    init(
        placeholder: String,
        text: Binding<String>,
        icon: String,
        keyboardType: UIKeyboardType = .default,
        isSecure: Bool = false,
        @ViewBuilder trailingButton: @escaping () -> Trailing = { EmptyView() },
        isFocused: Bool = false
    ) {
        self.placeholder    = placeholder
        self._text          = text
        self.icon           = icon
        self.keyboardType   = keyboardType
        self.isSecure       = isSecure
        self.trailingButton = trailingButton
        self.isFocused      = isFocused
    }

    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: icon)
                .foregroundColor(isFocused ? Color.laymanOrange : Color.laymanSubtext)
                .frame(width: 20)

            if isSecure {
                SecureField(placeholder, text: $text)
                    .font(.system(size: 16))
                    .foregroundColor(Color.laymanText)
                    .keyboardType(keyboardType)
            } else {
                TextField(placeholder, text: $text)
                    .font(.system(size: 16))
                    .foregroundColor(Color.laymanText)
                    .keyboardType(keyboardType)
                    .autocapitalization(.none)
                    .autocorrectionDisabled()
            }

            trailingButton()
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 16)
        .background(
            RoundedRectangle(cornerRadius: 12)
                .fill(Color.laymanSurface)
                .shadow(color: Color.black.opacity(0.07), radius: 4, x: 0, y: 2)
        )
        .overlay(
            RoundedRectangle(cornerRadius: 12)
                .stroke(isFocused ? Color.laymanOrange : Color.clear, lineWidth: 1.5)
        )
        .animation(.easeInOut(duration: 0.18), value: isFocused)
    }
}

#Preview {
    AuthView(viewModel: AuthViewModel())
}
