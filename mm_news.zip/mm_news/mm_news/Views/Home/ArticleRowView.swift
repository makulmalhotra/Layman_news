import SwiftUI

// MARK: - Article row for "Today's Picks" and Saved list
struct ArticleRowView: View {
    let article: Article
    var isSaved: Bool = false
    var onSave: (() -> Void)? = nil

    var body: some View {
        HStack(alignment: .top, spacing: 12) {
            // Thumbnail
            ArticleThumbnail(imageUrl: article.imageUrl)

            // Text content
            VStack(alignment: .leading, spacing: 5) {
                Text(article.laymanTitle)
                    .font(.system(size: 14, weight: .semibold, design: .default))
                    .foregroundColor(Color.laymanText)
                    .lineLimit(3)
                    .fixedSize(horizontal: false, vertical: true)

                HStack(spacing: 4) {
                    Text(article.sourceName)
                        .font(.system(size: 11, weight: .medium))
                        .foregroundColor(Color.laymanSubtext)
                    Text("·")
                        .foregroundColor(Color.laymanSubtext)
                    Text(article.formattedDate)
                        .font(.system(size: 11))
                        .foregroundColor(Color.laymanSubtext)
                    Spacer()
                }
            }

            // Save button
            if let onSave {
                Button(action: {
                    UIImpactFeedbackGenerator(style: .medium).impactOccurred()
                    onSave()
                }) {
                    Image(systemName: isSaved ? "bookmark.fill" : "bookmark")
                        .font(.system(size: 16))
                        .foregroundColor(isSaved ? Color.laymanOrange : Color.laymanSubtext)
                }
                .frame(width: 32, height: 32)
            }
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 12)
        .background(Color.laymanCard)
        .clipShape(RoundedRectangle(cornerRadius: 12))
        .shadow(color: Color.black.opacity(0.07), radius: 4, x: 0, y: 2)
    }
}

// MARK: - Article thumbnail
struct ArticleThumbnail: View {
    let imageUrl: String?
    var size: CGFloat = 72

    var body: some View {
        Group {
            if let urlStr = imageUrl, let url = URL(string: urlStr) {
                AsyncImage(url: url) { phase in
                    switch phase {
                    case .success(let img):
                        img.resizable()
                            .scaledToFill()
                            .frame(width: size, height: size)
                            .clipped()
                    case .failure:
                        thumbnailPlaceholder
                            .frame(width: size, height: size)
                    case .empty:
                        Color.laymanCard
                            .frame(width: size, height: size)
                            .overlay(ProgressView().tint(Color.laymanSubtext.opacity(0.5)))
                    @unknown default:
                        thumbnailPlaceholder
                            .frame(width: size, height: size)
                    }
                }
                .frame(width: size, height: size)
                .clipShape(RoundedRectangle(cornerRadius: 10))
            } else {
                thumbnailPlaceholder
                    .frame(width: size, height: size)
                    .clipShape(RoundedRectangle(cornerRadius: 10))
            }
        }
    }

    private var thumbnailPlaceholder: some View {
        LinearGradient(
            colors: [Color.laymanOrange.opacity(0.6), Color.gradientBottom],
            startPoint: .topLeading,
            endPoint: .bottomTrailing
        )
        .overlay(
            Image(systemName: "newspaper")
                .font(.system(size: 24))
                .foregroundColor(.white.opacity(0.8))
        )
    }
}
