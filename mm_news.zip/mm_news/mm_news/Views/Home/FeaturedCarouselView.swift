import SwiftUI

// MARK: - Featured Articles Carousel
struct FeaturedCarouselView: View {
    let articles: [Article]
    var onTap: (Article) -> Void
    var onSave: (Article) -> Void
    var isSaved: (Article) -> Bool

    @State private var currentIndex: Int = 0

    var body: some View {
        VStack(spacing: 10) {
            // Swipeable cards
            TabView(selection: $currentIndex) {
                ForEach(Array(articles.enumerated()), id: \.element.id) { index, article in
                    CarouselCard(article: article, onSave: { onSave(article) }, isSaved: isSaved(article))
                        .onTapGesture { onTap(article) }
                        .tag(index)
                }
            }
            .tabViewStyle(.page(indexDisplayMode: .never))
            .frame(height: 220)
            .onChange(of: currentIndex) { _, _ in UISelectionFeedbackGenerator().selectionChanged() }

            // Page indicator dots
            PageDots(count: articles.count, current: currentIndex)
        }
    }
}

// MARK: - Single carousel card
private struct CarouselCard: View {
    let article: Article
    var onSave: () -> Void
    var isSaved: Bool

    var body: some View {
        // RoundedRectangle anchors the fixed size — overlay clips everything to it
        RoundedRectangle(cornerRadius: 16)
            .fill(Color.laymanDarkOrange)
            .frame(maxWidth: .infinity)
            .frame(height: 220)
            .overlay(alignment: .bottom) {
                ZStack(alignment: .bottom) {
                    // Image fills the card exactly
                    articleImage

                    // Bottom gradient overlay
                    LinearGradient(
                        colors: [Color.clear, Color.black.opacity(0.72)],
                        startPoint: .center,
                        endPoint: .bottom
                    )

                    // Headline text
                    VStack(alignment: .leading, spacing: 4) {
                        if let source = article.sourceId {
                            Text(source.replacingOccurrences(of: "_", with: " ").uppercased())
                                .frame(maxWidth: .infinity, alignment: .leading)
                                .font(.system(size: 10, weight: .bold, design: .default))
                                .foregroundColor(Color.laymanOrange)
                                .kerning(1)
                        }
                        Text(article.laymanTitle)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .font(.system(size: 16, weight: .bold, design: .default))
                            .foregroundColor(.white)
                            .lineLimit(2)
                    }
                    .padding(.horizontal, 14)
                    .padding(.bottom, 14)
                    .frame(maxWidth: .infinity)
                }
                .frame(maxWidth: .infinity)
            }
            .clipShape(RoundedRectangle(cornerRadius: 16))
            .shadow(color: Color.black.opacity(0.12), radius: 8, x: 0, y: 4)
            .padding(.horizontal, 16)
    }

    @ViewBuilder
    private var articleImage: some View {
        if let urlStr = article.imageUrl, let url = URL(string: urlStr) {
            AsyncImage(url: url) { phase in
                switch phase {
                case .success(let image):
                    image.resizable()
                        .scaledToFill()
                case .failure, .empty:
                    placeholderBg
                @unknown default:
                    placeholderBg
                }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
        } else {
            placeholderBg
        }
    }

    private var placeholderBg: some View {
        LinearGradient(
            colors: [Color.laymanOrange.opacity(0.8), Color.laymanDarkOrange],
            startPoint: .topLeading,
            endPoint: .bottomTrailing
        )
    }
}

// MARK: - Page dots indicator
struct PageDots: View {
    let count: Int
    let current: Int

    var body: some View {
        HStack(spacing: 6) {
            ForEach(0..<count, id: \.self) { i in
                Capsule()
                    .fill(i == current ? Color.laymanOrange : Color.laymanSubtext.opacity(0.3))
                    .frame(width: i == current ? 18 : 6, height: 6)
                    .animation(.spring(response: 0.3, dampingFraction: 0.7), value: current)
            }
        }
    }
}
