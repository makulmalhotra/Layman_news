import SwiftUI

// MARK: - Articles / Home Screen (Screen 3)
struct HomeView: View {
    @Bindable var viewModel: HomeViewModel
    var onArticleTap: (Article) -> Void
    var showSearch: Bool = false
    @State private var isSearching: Bool = false
    @State private var showingAll: Bool = false

    var body: some View {
        ZStack(alignment: .top) {
            Color.laymanBackground.ignoresSafeArea()

            VStack(spacing: 0) {
                navBar
                if isSearching { searchBarView }
                contentScrollView
            }
        }
        .task { await viewModel.fetchArticles() }
    }

    // MARK: - Navigation bar
    private var navBar: some View {
        HStack {
            Text("Layman")
                .font(.system(size: 28, weight: .semibold, design: .serif))
                .foregroundColor(Color.laymanText)
            Spacer()
            Button {
                UIImpactFeedbackGenerator(style: .light).impactOccurred()
                withAnimation(.easeInOut(duration: 0.2)) {
                    isSearching.toggle()
                    if !isSearching { viewModel.searchText = "" }
                }
            } label: {
                Image(systemName: isSearching ? "xmark.circle.fill" : "magnifyingglass")
                    .font(.system(size: 22, weight: .medium))
                    .foregroundColor(Color.laymanText)
            }
        }
        .padding(.horizontal, 20)
        .padding(.top, 12)
        .padding(.bottom, 10)
        .background(Color.laymanBackground)
    }

    // MARK: - Search bar
    private var searchBarView: some View {
        HStack(spacing: 10) {
            Image(systemName: "magnifyingglass")
                .foregroundColor(Color.laymanSubtext)
            TextField("Search articles...", text: $viewModel.searchText)
                .font(.system(size: 15))
                .foregroundColor(Color.laymanText)
                .autocorrectionDisabled()
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 10)
        .background(Color.white)
        .clipShape(RoundedRectangle(cornerRadius: 10))
        .padding(.horizontal, 20)
        .padding(.bottom, 10)
        .transition(.opacity.combined(with: .move(edge: .top)))
    }

    // MARK: - Scrollable content
    private var contentScrollView: some View {
        ScrollView(showsIndicators: false) {
            LazyVStack(alignment: .leading, spacing: 0) {
                if viewModel.isLoading {
                    loadingView
                } else if let err = viewModel.errorMessage {
                    errorView(message: err)
                } else {
                    if !viewModel.featuredArticles.isEmpty && !isSearching {
                        featuredSection
                        Spacer().frame(height: 24)
                    }
                    todaysPicksSection
                }
            }
            .padding(.bottom, 100)
        }
    }

    // MARK: - Featured carousel section
    private var featuredSection: some View {
        FeaturedCarouselView(
            articles: viewModel.featuredArticles,
            onTap: { onArticleTap($0) },
            onSave: { article in Task { await viewModel.toggleSave(article: article) } },
            isSaved: { viewModel.isSaved($0) }
        )
    }

    // MARK: - Today's Picks section
    private var todaysPicksSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            // Section header
            HStack {
                Text(isSearching ? "Search Results" : "Today's Picks")
                    .font(.system(size: 18, weight: .bold))
                    .foregroundColor(Color.laymanText)
                Spacer()
                if !isSearching {
                    Button(showingAll ? "Show Less" : "View All") {
                        UISelectionFeedbackGenerator().selectionChanged()
                        withAnimation(.easeInOut(duration: 0.2)) {
                            showingAll.toggle()
                        }
                    }
                    .font(.system(size: 13, weight: .semibold))
                    .foregroundColor(Color.laymanOrange)
                    .buttonStyle(ScaleButtonStyle())
                }
            }
            .padding(.horizontal, 20)

            let picks = isSearching
                ? viewModel.filteredTodaysPicks
                : (showingAll ? viewModel.nonFeaturedArticles : viewModel.todaysPicks)
            if picks.isEmpty {
                emptySearchView
            } else {
                ForEach(picks) { article in
                    ArticleRowView(
                        article: article,
                        isSaved: viewModel.isSaved(article),
                        onSave: { Task { await viewModel.toggleSave(article: article) } }
                    )
                    .padding(.horizontal, 16)
                    .onTapGesture { onArticleTap(article) }
                }
            }
        }
    }

    // MARK: - Helper views
    private var loadingView: some View {
        VStack(spacing: 16) {
            Spacer().frame(height: 60)
            ProgressView()
                .progressViewStyle(CircularProgressViewStyle(tint: Color.laymanOrange))
                .scaleEffect(1.3)
            Text("Loading news…")
                .font(.system(size: 14))
                .foregroundColor(Color.laymanSubtext)
            Spacer()
        }
        .frame(maxWidth: .infinity)
    }

    private func errorView(message: String) -> some View {
        VStack(spacing: 16) {
            Spacer().frame(height: 60)
            Image(systemName: "wifi.exclamationmark")
                .font(.system(size: 40))
                .foregroundColor(Color.laymanSubtext)
            Text(message)
                .font(.system(size: 14))
                .foregroundColor(Color.laymanSubtext)
                .multilineTextAlignment(.center)
                .padding(.horizontal, 40)
            Button("Retry") { Task { await viewModel.fetchArticles() } }
                .foregroundColor(Color.laymanOrange)
                .font(.system(size: 15, weight: .semibold))
            Spacer()
        }
        .frame(maxWidth: .infinity)
    }

    private var emptySearchView: some View {
        VStack(spacing: 10) {
            Spacer().frame(height: 40)
            Image(systemName: "doc.text.magnifyingglass")
                .font(.system(size: 36))
                .foregroundColor(Color.laymanSubtext.opacity(0.5))
            Text("No articles found")
                .font(.system(size: 14))
                .foregroundColor(Color.laymanSubtext)
            Spacer()
        }
        .frame(maxWidth: .infinity)
    }
}
