import SwiftUI

// MARK: - Main Tab Bar Container
struct MainTabView: View {
    @Bindable var authViewModel: AuthViewModel
    @State private var homeViewModel  = HomeViewModel()
    @State private var selectedTab: Tab = .home
    @State private var selectedArticle: Article? = nil

    enum Tab { case home, saved, profile }

    var body: some View {
        ZStack {
            // Tab content
            tabContent

            // Custom tab bar pinned to bottom
            VStack(spacing: 0) {
                Spacer()
                customTabBar
            }
            .ignoresSafeArea(edges: .bottom)
        }
        .onAppear {
            if let session = authViewModel.currentSession {
                homeViewModel.configure(session: session)
            }
        }
        // Full-screen article detail navigation
        .fullScreenCover(item: $selectedArticle) { article in
            ArticleDetailView(
                article: article,
                isSaved: homeViewModel.isSaved(article),
                onSave: { Task { await homeViewModel.toggleSave(article: article) } },
                onBack: { selectedArticle = nil }
            )
        }
    }

    // MARK: - Tab content switcher
    @ViewBuilder
    private var tabContent: some View {
        switch selectedTab {
        case .home:
            HomeView(
                viewModel: homeViewModel,
                onArticleTap: { selectedArticle = $0 }
            )
        case .saved:
            SavedView(
                viewModel: homeViewModel,
                onArticleTap: { selectedArticle = $0 }
            )
        case .profile:
            ProfileView(authViewModel: authViewModel)
        }
    }

    // MARK: - Custom bottom tab bar
    private var customTabBar: some View {
        HStack(spacing: 0) {
            TabBarButton(
                icon: "house",
                activeIcon: "house.fill",
                label: "Home",
                isActive: selectedTab == .home
            ) { selectedTab = .home }

            TabBarButton(
                icon: "bookmark",
                activeIcon: "bookmark.fill",
                label: "Saved",
                isActive: selectedTab == .saved
            ) { selectedTab = .saved }

            TabBarButton(
                icon: "person",
                activeIcon: "person.fill",
                label: "Profile",
                isActive: selectedTab == .profile
            ) { selectedTab = .profile }
        }
        .padding(.top, 12)
        .padding(.bottom, 28)
        .background(
            Rectangle()
                .fill(Color.laymanTabBar)
                .shadow(color: Color.black.opacity(0.18), radius: 16, x: 0, y: -4)
        )
        .overlay(alignment: .top) {
            Rectangle()
                .fill(Color.laymanSubtext.opacity(0.15))
                .frame(height: 0.5)
        }
    }
}

// MARK: - Tab bar button
private struct TabBarButton: View {
    let icon: String
    let activeIcon: String
    let label: String
    let isActive: Bool
    let action: () -> Void

    var body: some View {
        Button {
            UISelectionFeedbackGenerator().selectionChanged()
            action()
        } label: {
            VStack(spacing: 4) {
                Image(systemName: isActive ? activeIcon : icon)
                    .font(.system(size: 22, weight: .medium))
                    .foregroundColor(isActive ? Color.laymanOrange : Color.laymanSubtext.opacity(0.6))
                Text(label)
                    .font(.system(size: 10, weight: .medium))
                    .foregroundColor(isActive ? Color.laymanOrange : Color.laymanSubtext.opacity(0.6))
            }
            .frame(maxWidth: .infinity)
        }
        .animation(.easeInOut(duration: 0.15), value: isActive)
    }
}
