import SwiftUI

// MARK: - Profile Screen
struct ProfileView: View {
    @Bindable var authViewModel: AuthViewModel
    @State private var notificationsOn: Bool = false
    @State private var streakPulse: Bool = false

    var body: some View {
        ZStack {
            Color.laymanBackground.ignoresSafeArea()
            VStack(spacing: 0) {
                header
                ScrollView(showsIndicators: false) {
                    VStack(spacing: 16) {
                        userInfoCard
                        streakCard
                        settingsSection
                        signOutButton
                        Spacer().frame(height: 80)
                    }
                    .padding(.horizontal, 20)
                    .padding(.top, 8)
                }
            }
        }
        .task {
            notificationsOn = await NotificationService.shared.isAuthorized()
        }
    }

    // MARK: - Header
    private var header: some View {
        HStack {
            Text("Profile")
                .font(.system(size: 28, weight: .semibold, design: .serif))
                .foregroundColor(Color.laymanText)
            Spacer()
        }
        .padding(.horizontal, 20)
        .padding(.top, 12)
        .padding(.bottom, 16)
    }

    // MARK: - User info card
    private var userInfoCard: some View {
        HStack(spacing: 16) {
            ZStack {
                Circle()
                    .fill(LinearGradient(
                        colors: [Color.laymanOrange, Color.laymanDarkOrange],
                        startPoint: .topLeading, endPoint: .bottomTrailing
                    ))
                    .frame(width: 60, height: 60)
                Text(initials)
                    .font(.system(size: 22, weight: .bold))
                    .foregroundColor(.white)
            }
            VStack(alignment: .leading, spacing: 4) {
                Text(authViewModel.currentSession?.email ?? "Reader")
                    .font(.system(size: 16, weight: .semibold))
                    .foregroundColor(Color.laymanText)
                Text("Layman reader")
                    .font(.system(size: 13))
                    .foregroundColor(Color.laymanSubtext)
            }
            Spacer()
        }
        .padding(20)
        .background(Color.laymanCard)
        .clipShape(RoundedRectangle(cornerRadius: 16))
        .shadow(color: Color.black.opacity(0.06), radius: 6, x: 0, y: 2)
    }

    private var initials: String {
        String((authViewModel.currentSession?.email ?? "L").prefix(1)).uppercased()
    }

    // MARK: - Reading Streak Card
    private var streakCard: some View {
        HStack(spacing: 0) {
            VStack(spacing: 4) {
                HStack(spacing: 6) {
                    Text("🔥")
                        .font(.system(size: 26))
                        .scaleEffect(streakPulse ? 1.25 : 1.0)
                    Text("\(StreakManager.shared.currentStreak)")
                        .font(.system(size: 36, weight: .bold))
                        .foregroundColor(Color.laymanOrange)
                }
                Text("day streak")
                    .font(.system(size: 12, weight: .medium))
                    .foregroundColor(Color.laymanSubtext)
            }
            .frame(maxWidth: .infinity)

            Rectangle()
                .fill(Color.laymanSubtext.opacity(0.2))
                .frame(width: 1, height: 50)

            VStack(spacing: 4) {
                Text("\(StreakManager.shared.longestStreak)")
                    .font(.system(size: 36, weight: .bold))
                    .foregroundColor(Color.laymanText)
                Text("best streak")
                    .font(.system(size: 12, weight: .medium))
                    .foregroundColor(Color.laymanSubtext)
            }
            .frame(maxWidth: .infinity)
        }
        .padding(.vertical, 20)
        .background(Color.laymanCard)
        .clipShape(RoundedRectangle(cornerRadius: 16))
        .shadow(color: Color.black.opacity(0.06), radius: 6, x: 0, y: 2)
        .onAppear {
            withAnimation(.spring(response: 0.4, dampingFraction: 0.5)) { streakPulse = true }
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.6) {
                withAnimation { streakPulse = false }
            }
        }
    }

    // MARK: - Settings
    private var settingsSection: some View {
        VStack(spacing: 0) {
            // Daily digest toggle
            HStack(spacing: 14) {
                Image(systemName: "bell.fill")
                    .font(.system(size: 17))
                    .foregroundColor(Color.laymanOrange)
                    .frame(width: 26)
                Text("Daily Digest")
                    .font(.system(size: 16))
                    .foregroundColor(Color.laymanText)
                Spacer()
                Toggle("", isOn: $notificationsOn)
                    .tint(Color.laymanOrange)
                    .onChange(of: notificationsOn) { _, on in
                        UIImpactFeedbackGenerator(style: .light).impactOccurred()
                        if on {
                            Task {
                                await NotificationService.shared.requestPermission()
                                NotificationService.shared.scheduleDailyDigest()
                            }
                        } else {
                            NotificationService.shared.cancelAll()
                        }
                    }
            }
            .padding(.horizontal, 20)
            .padding(.vertical, 16)

            Divider().padding(.leading, 52)

            // Dark mode row (informational — uses system setting)
            HStack(spacing: 14) {
                Image(systemName: "moon.fill")
                    .font(.system(size: 17))
                    .foregroundColor(Color.laymanOrange)
                    .frame(width: 26)
                Text("Dark Mode")
                    .font(.system(size: 16))
                    .foregroundColor(Color.laymanText)
                Spacer()
                Text("System")
                    .font(.system(size: 14))
                    .foregroundColor(Color.laymanSubtext)
            }
            .padding(.horizontal, 20)
            .padding(.vertical, 16)

            Divider().padding(.leading, 52)

            ProfileRow(icon: "info.circle", title: "About Layman", showChevron: true) {}
        }
        .background(Color.laymanCard)
        .clipShape(RoundedRectangle(cornerRadius: 16))
        .shadow(color: Color.black.opacity(0.06), radius: 6, x: 0, y: 2)
    }

    // MARK: - Sign out
    private var signOutButton: some View {
        Button {
            UIImpactFeedbackGenerator(style: .medium).impactOccurred()
            Task { await authViewModel.signOut() }
        } label: {
            HStack {
                Image(systemName: "rectangle.portrait.and.arrow.right")
                    .foregroundColor(.red)
                Text("Sign Out")
                    .font(.system(size: 16, weight: .semibold))
                    .foregroundColor(.red)
                Spacer()
            }
            .padding(20)
            .background(Color.laymanCard)
            .clipShape(RoundedRectangle(cornerRadius: 16))
            .shadow(color: Color.black.opacity(0.06), radius: 6, x: 0, y: 2)
        }
    }
}

// MARK: - Profile row
private struct ProfileRow: View {
    let icon: String
    let title: String
    var showChevron: Bool
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            HStack(spacing: 14) {
                Image(systemName: icon)
                    .font(.system(size: 17))
                    .foregroundColor(Color.laymanOrange)
                    .frame(width: 26)
                Text(title)
                    .font(.system(size: 16))
                    .foregroundColor(Color.laymanText)
                Spacer()
                if showChevron {
                    Image(systemName: "chevron.right")
                        .font(.system(size: 13, weight: .semibold))
                        .foregroundColor(Color.laymanSubtext.opacity(0.5))
                }
            }
            .padding(.horizontal, 20)
            .padding(.vertical, 16)
        }
    }
}
