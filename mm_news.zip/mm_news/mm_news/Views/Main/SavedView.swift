import SwiftUI

// MARK: - Saved Articles Screen
struct SavedView: View {
    @Bindable var viewModel: HomeViewModel
    var onArticleTap: (Article) -> Void

    @State private var isSearching: Bool = false
    @State private var searchText: String = ""

    var filteredSaved: [Article] {
        if searchText.trimmingCharacters(in: .whitespaces).isEmpty { return viewModel.savedArticles }
        let q = searchText.lowercased()
        return viewModel.savedArticles.filter { $0.title.lowercased().contains(q) }
    }

    var body: some View {
        ZStack(alignment: .top) {
            Color.laymanBackground.ignoresSafeArea()

            VStack(spacing: 0) {
                // Header
                HStack {
                    Text("Saved")
                        .font(.system(size: 28, weight: .semibold, design: .serif))
                        .foregroundColor(Color.laymanText)
                    Spacer()
                    Button {
                        withAnimation(.easeInOut(duration: 0.2)) {
                            isSearching.toggle()
                            if !isSearching { searchText = "" }
                        }
                    } label: {
                        Image(systemName: isSearching ? "xmark.circle.fill" : "magnifyingglass")
                            .font(.system(size: 22, weight: .medium))
                            .foregroundColor(Color.laymanText)
                    }
                }
                .padding(.horizontal, 20)
                .padding(.top, 12)
                .padding(.bottom, 10)

                if isSearching {
                    HStack(spacing: 10) {
                        Image(systemName: "magnifyingglass")
                            .foregroundColor(Color.laymanSubtext)
                        TextField("Search saved…", text: $searchText)
                            .font(.system(size: 15))
                            .foregroundColor(Color.laymanText)
                    }
                    .padding(.horizontal, 14)
                    .padding(.vertical, 10)
                    .background(Color.white)
                    .clipShape(RoundedRectangle(cornerRadius: 10))
                    .padding(.horizontal, 20)
                    .padding(.bottom, 10)
                    .transition(.opacity.combined(with: .move(edge: .top)))
                }

                if viewModel.savedArticles.isEmpty {
                    emptySavedView
                } else {
                    ScrollView(showsIndicators: false) {
                        LazyVStack(spacing: 10) {
                            ForEach(filteredSaved) { article in
                                ArticleRowView(
                                    article: article,
                                    isSaved: true,
                                    onSave: { Task { await viewModel.toggleSave(article: article) } }
                                )
                                .padding(.horizontal, 16)
                                .onTapGesture { onArticleTap(article) }
                            }
                        }
                        .padding(.top, 8)
                        .padding(.bottom, 24)
                    }
                }
            }
        }
        .animation(.easeInOut(duration: 0.2), value: isSearching)
    }

    private var emptySavedView: some View {
        VStack(spacing: 16) {
            Spacer()
            Image(systemName: "bookmark")
                .font(.system(size: 48))
                .foregroundColor(Color.laymanSubtext.opacity(0.4))
            VStack(spacing: 6) {
                Text("No saved articles yet")
                    .font(.system(size: 17, weight: .semibold))
                    .foregroundColor(Color.laymanText)
                Text("Tap the bookmark icon on any article to save it here.")
                    .font(.system(size: 14))
                    .foregroundColor(Color.laymanSubtext)
                    .multilineTextAlignment(.center)
                    .padding(.horizontal, 40)
            }
            Spacer()
        }
        .frame(maxWidth: .infinity)
    }
}
