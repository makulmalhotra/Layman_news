import SwiftUI

// MARK: - Welcome Screen
struct WelcomeView: View {
    var onGetStarted: () -> Void

    @State private var logoOpacity: Double = 0
    @State private var sloganOpacity: Double = 0
    @State private var sloganOffset: CGFloat = 24
    @State private var sliderOpacity: Double = 0

    var body: some View {
        ZStack {
            // Warm peach-to-orange background gradient
            LinearGradient(
                stops: [
                    Gradient.Stop(color: .gradientTop,    location: 0.00),
                    Gradient.Stop(color: .gradientMid,    location: 0.50),
                    Gradient.Stop(color: .gradientBottom, location: 1.00)
                ],
                startPoint: .top,
                endPoint: .bottom
            )
            .ignoresSafeArea()

            VStack(spacing: 0) {
                // Logo
                Text("Layman")
                    .font(.system(size: 38, weight: .semibold, design: .serif))
                    .foregroundColor(Color.laymanText)
                    .padding(.top, 72)
                    .opacity(logoOpacity)

                Spacer()

                // Slogan
                VStack(alignment: .center, spacing: 4) {
                    Text("Business,")
                        .font(.system(size: 32, weight: .bold))
                        .foregroundColor(Color.laymanText)
                    Text("tech & startups")
                        .font(.system(size: 32, weight: .bold))
                        .foregroundColor(Color.laymanText)
                    Text("made simple")
                        .font(.system(size: 32, weight: .bold))
                        .italic()
                        .foregroundColor(Color.laymanOrange)
                }
                .frame(maxWidth: .infinity, alignment: .center)
                .multilineTextAlignment(.center)
                .padding(.horizontal, 32)
                .opacity(sloganOpacity)
                .offset(y: sloganOffset)

                Spacer()

                // Swipe slider
                SwipeToStartSlider(onComplete: onGetStarted)
                    .padding(.horizontal, 28)
                    .padding(.bottom, 52)
                    .opacity(sliderOpacity)
            }
        }
        .onAppear {
            withAnimation(.easeIn(duration: 0.6)) { logoOpacity = 1 }
            withAnimation(.easeOut(duration: 0.7).delay(0.35)) {
                sloganOpacity = 1
                sloganOffset  = 0
            }
            withAnimation(.easeIn(duration: 0.5).delay(0.8)) { sliderOpacity = 1 }
        }
    }
}

// MARK: - Swipe-to-start Slider
struct SwipeToStartSlider: View {
    var onComplete: () -> Void

    @State private var dragOffset: CGFloat = 0
    @State private var isCompleted: Bool = false

    private let sliderHeight: CGFloat   = 62
    private let thumbDiameter: CGFloat  = 52
    private let edgePad: CGFloat        = 5

    var body: some View {
        GeometryReader { geo in
            let maxDrag: CGFloat = geo.size.width - thumbDiameter - edgePad * 2
            let progress: CGFloat = maxDrag > 0 ? dragOffset / maxDrag : 0

            ZStack(alignment: .leading) {
                // Track background
                Capsule()
                    .fill(Color.laymanText.opacity(0.12))
                    .overlay(Capsule().stroke(Color.laymanText.opacity(0.25), lineWidth: 1))

                // Growing fill as thumb moves
                Capsule()
                    .fill(Color.laymanOrange.opacity(0.20))
                    .frame(width: max(thumbDiameter + edgePad * 2,
                                     dragOffset + thumbDiameter + edgePad * 2))
                    .animation(.interactiveSpring(), value: dragOffset)

                // "Swipe to get started" label
                SliderLabel(progress: progress)

                // Draggable thumb
                SliderThumb(diameter: thumbDiameter)
                    .offset(x: edgePad + dragOffset)
                    .gesture(
                        DragGesture(minimumDistance: 4)
                            .onChanged { value in
                                guard !isCompleted else { return }
                                dragOffset = min(max(0, value.translation.width), maxDrag)
                            }
                            .onEnded { _ in
                                guard !isCompleted else { return }
                                if dragOffset > maxDrag * 0.72 {
                                    withAnimation(.spring(response: 0.28, dampingFraction: 0.75)) {
                                        dragOffset  = maxDrag
                                        isCompleted = true
                                    }
                                    UINotificationFeedbackGenerator().notificationOccurred(.success)
                                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.32) {
                                        onComplete()
                                    }
                                } else {
                                    UIImpactFeedbackGenerator(style: .light).impactOccurred()
                                    withAnimation(.spring(response: 0.45, dampingFraction: 0.68)) {
                                        dragOffset = 0
                                    }
                                }
                            }
                    )
            }
            .frame(height: sliderHeight)
        }
        .frame(height: sliderHeight)
    }
}

// Separate struct so type inference for .font is unambiguous
private struct SliderLabel: View {
    let progress: CGFloat

    var body: some View {
        // Apply .frame first so type becomes 'some View', not 'Text',
        // resolving the Swift 6.2 Text.font / View.font ambiguity.
        Text("Swipe to get started")
            .frame(maxWidth: .infinity)
            .font(.system(size: 15, weight: .semibold, design: .default))
            .foregroundColor(Color.laymanText.opacity(0.75))
            .allowsHitTesting(false)
            .opacity(Double(max(0.0, 1.0 - progress * 2.0)))
    }
}

private struct SliderThumb: View {
    let diameter: CGFloat

    var body: some View {
        ZStack {
            Circle()
                .fill(
                    LinearGradient(
                        colors: [Color.laymanOrange, Color.laymanDarkOrange],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    )
                )
                .frame(width: diameter, height: diameter)
                .shadow(color: Color.laymanDarkOrange.opacity(0.45), radius: 6, x: 0, y: 3)

            HStack(spacing: -2) {
                Image(systemName: "chevron.right")
                    .font(.system(size: 13, weight: .bold))
                    .foregroundColor(Color.white)
                Image(systemName: "chevron.right")
                    .font(.system(size: 13, weight: .bold))
                    .foregroundColor(Color.white.opacity(0.55))
            }
        }
    }
}

#Preview {
    WelcomeView(onGetStarted: {})
}
